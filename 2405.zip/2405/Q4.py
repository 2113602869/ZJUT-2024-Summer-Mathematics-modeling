import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
from heapq import heappop, heappush


#------------------------tsp函数------------------------
# 计算两点之间的曼哈顿距离
def manhattan_distance(p1, p2):
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


# A* 算法
def a_star(maze, start, goal):
    n = len(maze)
    open_set = [(0, start)]
    came_from = {}
    g_score = {tuple(start): 0}
    f_score = {tuple(start): manhattan_distance(start, goal)}

    while open_set:
        _, current = heappop(open_set)

        if tuple(current) == tuple(goal):
            path = [goal]
            while tuple(path[-1]) != tuple(start):
                path.append(came_from[tuple(path[-1])])
            return list(reversed(path))

        for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
            neighbor = (current[0] + dx, current[1] + dy)
            if 0 <= neighbor[0] < n and 0 <= neighbor[1] < n and maze[neighbor[0]][neighbor[1]] == 0:
                tentative_g_score = g_score[tuple(current)] + 1
                if tuple(neighbor) not in g_score or tentative_g_score < g_score[tuple(neighbor)]:
                    came_from[tuple(neighbor)] = current
                    g_score[tuple(neighbor)] = tentative_g_score
                    f_score[tuple(neighbor)] = tentative_g_score + manhattan_distance(neighbor, goal)
                    heappush(open_set, (f_score[tuple(neighbor)], neighbor))

    return None


# 计算路径总长度
def path_length(path, cities):
    total_distance = 0
    for i in range(len(path) - 1):
        total_distance += manhattan_distance(cities[path[i]], cities[path[i + 1]])
    total_distance += manhattan_distance(cities[path[-1]], cities[path[0]])  # 返回起点
    return total_distance


# 模拟退火算法
def tsp_simulated_annealing(cities, maze, initial_temperature=1000, cooling_rate=0.999999, iterations=1000000):
    n = len(cities)
    # 从第一个城市开始
    current_path = np.arange(n)
    # 不需要打乱路径，因为我们要从第一个城市开始
    best_path = current_path.copy()
    best_length = path_length(best_path, cities)

    temperature = initial_temperature

    for _ in range(iterations):
        new_path = current_path.copy()
        # 随机选择两个位置进行交换
        i, j = np.random.choice(n, 2, replace=False)
        new_path[i], new_path[j] = new_path[j], new_path[i]

        current_length = path_length(current_path, cities)
        new_length = path_length(new_path, cities)

        if new_length < current_length or np.exp((current_length - new_length) / temperature) > np.random.rand():
            current_path = new_path
            if new_length < best_length:
                best_path = new_path.copy()
                best_length = new_length

        temperature *= cooling_rate

    # 调整路径顺序，确保从索引为 0 的城市开始
    zero_index = np.where(best_path == 0)[0][0]
    best_path = np.concatenate((best_path[zero_index:], best_path[:zero_index]))

    # 将城市坐标转换为迷宫中的路径
    path = [cities[best_path[0]]]
    for i in range(1, len(best_path)):
        path.extend(a_star(maze, path[-1], cities[best_path[i]])[1:])
    path.extend(a_star(maze, path[-1], cities[best_path[0]])[1:])  # 返回起点

    return best_path, path, best_length


# ------------------------寻找最优关节角路径函数------------------------
# 计算变换矩阵,传统D-H法
def standard_calc_transform_matrix(param):
    theta, d, a, alpha = param['theta'], param['d'], param['a'], param['alpha']

    return np.array([[np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
                     [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
                     [0, np.sin(alpha), np.cos(alpha), d],
                     [0, 0, 0, 1]])


# 目标函数：计算末端位置与目标位置之间的欧几里得距离和能耗
def objective_function(angles, target_position):
    T = np.eye(4)
    energy_consumption = gravitational_potential
    for i, param in enumerate(params[1:], start=1):
        param['theta'] = angles[i - 1]
        T = T @ standard_calc_transform_matrix(param)
        energy_consumption += 0.5 * param['I'] * param['omega'] ** 2
    end_effector_position = T[:3, 3]
    position_error = np.linalg.norm(end_effector_position - target_position)
    if position_error > 200:
        position_error = 200  # 误差阈值处理
    # 动态调整能量权重
    energy_weight = 0.01 + 0.001 * max(0, 200 - position_error) / 200
    total_error = position_error + energy_weight * energy_consumption
    return float(total_error)


# 辅助函数：确保角度在给定的范围内
def clip_angle(theta, lower_limit, high_limit):
    # 确保角度在给定的范围内
    return max(lower_limit, min(high_limit, theta))


# 局部搜索：梯度下降
def local_search(individual, learning_rate=0.01, iterations=100):
    for _ in range(iterations):
        gradient = np.zeros_like(individual)
        for i in range(len(individual)):
            epsilon = 1e-16
            individual_plus = individual.copy()
            individual_plus[i] += epsilon
            individual_minus = individual.copy()
            individual_minus[i] -= epsilon
            gradient[i] = (objective_function(individual_plus, target_position) -
                           objective_function(individual_minus, target_position)) / (2 * epsilon)

        # 更新个体
        individual -= learning_rate * gradient
        # 确保角度在有效范围内
        for i in range(len(individual)):
            individual[i] = clip_angle(individual[i], params[i]['lower_limit'], params[i]['high_limit'])
    return individual


# 多点交叉
def multipoint_crossover(parent1, parent2, num_points=2):
    crossover_points = sorted(random.sample(range(1, len(parent1)), num_points))
    child1, child2 = parent1.copy(), parent2.copy()

    for i in range(num_points):
        start = crossover_points[i]
        end = crossover_points[(i + 1) % num_points] if i < num_points - 1 else len(parent1)
        child1[start:end], child2[start:end] = child2[start:end], child1[start:end]
    return child1, child2


# 定义用于调整参数的函数
def adjust_parameters(crossover_rate, mutation_rate, best_fitness, prev_best_fitness):
    improvement_threshold = 0.01  # 改善阈值
    diversity_threshold = 0.01  # 多样性阈值

    # 检查是否有显著改善
    if best_fitness > prev_best_fitness + improvement_threshold:
        mutation_rate *= 0.9  # 减少变异率
    else:
        mutation_rate *= 1.1  # 增加变异率

    # 检查种群多样性
    if mutation_rate > 0.5:
        crossover_rate *= 0.9  # 减少交叉率
    else:
        crossover_rate *= 1.1  # 增加交叉率

    # 限制参数范围
    crossover_rate = max(min(crossover_rate, 1.0), 0.0)
    mutation_rate = max(min(mutation_rate, 1.0), 0.0)

    return crossover_rate, mutation_rate


# 定义模拟退火算法
def adaptive_simulated_annealing(initial_solution, initial_temperature, cooling_factor, max_iterations,
                                 objective_function, target_position, improvement_threshold=0.001,
                                 diversity_threshold=0.01):
    current_solution = initial_solution
    current_fitness = objective_function(current_solution, target_position)
    best_solution = current_solution
    best_fitness = current_fitness

    temperature = initial_temperature
    prev_best_fitness = best_fitness

    for iteration in range(max_iterations):
        # Generate a new candidate solution
        candidate_solution = current_solution + np.random.uniform(-0.01, 0.01, size=len(current_solution))
        for i in range(len(candidate_solution)):
            candidate_solution[i] = clip_angle(candidate_solution[i], params[i]['lower_limit'], params[i]['high_limit'])

        candidate_fitness = objective_function(candidate_solution, target_position)

        # Calculate the change in fitness
        delta_fitness = candidate_fitness - current_fitness

        # Acceptance probability
        if delta_fitness < 0 or np.exp(-delta_fitness / temperature) > np.random.rand():
            current_solution = candidate_solution
            current_fitness = candidate_fitness

            # Update the best solution
            if current_fitness < best_fitness:
                best_solution = current_solution
                best_fitness = current_fitness
                prev_best_fitness = best_fitness

        # Adaptive cooling
        if best_fitness > prev_best_fitness + improvement_threshold:
            cooling_factor *= 0.09  # Faster cooling
        elif temperature > diversity_threshold:
            cooling_factor *= 1.01  # Slower cooling

        # Cool down the temperature
        temperature *= cooling_factor

    return best_solution, best_fitness


if __name__ == '__main__':
    # ------------------------寻找最优底座移动路径------------------------
    df = pd.read_excel('附件.xlsx', sheet_name='Sheet2')
    grid = []
    start = (0, 0)
    target= {"Start" : (0, 0)}
    cities=[start]
    for i in range(len(df)):
        grid.append(df.iloc[i].tolist())

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == "Start":
                start = (i, j)
                grid[i][j] = 0
            if type(grid[i][j]) == str and grid[i][j][:6] == "target":
                target[grid[i][j]]=(i,j)
                cities.append((i,j))
                grid[i][j] = 0
    grid=np.array(grid)
    reversed_dict = {value: key for key, value in target.items()}

    # 使用模拟退火算法求解
    best_path_indices, best_path, best_length = tsp_simulated_annealing(cities, grid)
    print("最佳路径长度:", best_length)
    print("最佳路径顺序 (索引):", best_path_indices)
    for i in range(len(best_path_indices)):
        print(reversed_dict[cities[best_path_indices[i]]], end=' -> ')
    print(reversed_dict[cities[best_path_indices[0]]])

    # 可视化结果
    plt.figure(figsize=(10, 6))
    plt.imshow(grid, cmap='gray', origin='lower')

    # 标记起始点
    start_point = cities[0]
    plt.plot(start_point[1], start_point[0], 'go', markersize=18, label='Start Point')

    # 标记每个城市的编号
    for i, city in enumerate(cities):
        plt.text(city[1], city[0], str(i), color='black', fontsize=10, ha='center', va='center')
        plt.plot(city[1], city[0], 'go', markersize=10)

    for i in range(len(best_path)):
        plt.plot(best_path[i][1], best_path[i][0], 'ro')
        if i < len(best_path) - 1:
            plt.plot([best_path[i][1], best_path[i + 1][1]], [best_path[i][0], best_path[i + 1][0]], 'b-')

    plt.legend()
    plt.title('Final Path')
    plt.savefig('Q4_path.png')
    plt.show()

    # ------------------------寻找最优关节角路径------------------------
    # 定义连杆参数
    params = [
        {'a': 0, 'alpha': 0, 'd': 600, 'theta': 0, 'lower_limit': -np.pi * 160 / 180, 'high_limit': np.pi * 160 / 180,
         'I': 0.5, 'omega': 2.0},  # 连杆1
        {'a': 300, 'alpha': -np.pi / 2, 'd': 0, 'theta': -np.pi / 2, 'lower_limit': -np.pi * 150 / 180,
         'high_limit': np.pi * 15 / 180, 'I': 0.3, 'omega': 1.5},  # 连杆2
        {'a': 1200, 'alpha': 0, 'd': 0, 'theta': 0, 'lower_limit': -np.pi * 200 / 180, 'high_limit': np.pi * 80 / 180,
         'I': 0.4, 'omega': 1.0},  # 连杆3
        {'a': 300, 'alpha': -np.pi / 2, 'd': 1200, 'theta': np.pi, 'lower_limit': -np.pi * 180 / 180,
         'high_limit': np.pi * 180 / 180, 'I': 0.6, 'omega': 2.5},  # 连杆4
        {'a': 0, 'alpha': -np.pi / 2, 'd': 0, 'theta': -np.pi / 2, 'lower_limit': -np.pi * 120 / 180,
         'high_limit': np.pi * 120 / 180, 'I': 0.2, 'omega': 3.0},  # 连杆5
        {'a': 0, 'alpha': -np.pi / 2, 'd': 0, 'theta': 0, 'lower_limit': -np.pi * 180 / 180,
         'high_limit': np.pi * 180 / 180, 'I': 0.4, 'omega': 2.0}  # 连杆6
    ]
    target_position = np.array([1500, 1200, 200])
    num_joints = len(params)

    # 初始化变换矩阵
    T = np.eye(4)
    T_i = np.eye(4) @ standard_calc_transform_matrix({'a': 0, 'alpha': 0, 'd': 0, 'theta': 0})
    for param in params:
        T_i = T_i @ standard_calc_transform_matrix(param)
    end_position = T_i[:3, 3]
    change_h = (end_position[2] - target_position[2]) / 1000
    M = 5
    g = 10
    gravitational_potential = M * g * change_h

    # 自适应遗传算法
    # 遗传算法参数
    population_size = 100
    num_generations = 50
    crossover_rate = 0.8
    mutation_rate = 0.1
    elite_count = 2  # 精英个体的数量
    num_crossover_points = 2  # 多点交叉的点数

    # 初始化种群
    population = [
        [clip_angle(np.random.uniform(params[i]['lower_limit'], params[i]['high_limit']),
                    params[i]['lower_limit'], params[i]['high_limit'])
         for i in range(num_joints)]
        for _ in range(population_size)
    ]

    # 初始化变量用于记录最佳解
    best_solution = None
    best_fitness = float('-inf')
    best_solution_generation = 0

    # 遗传算法主循环
    prev_best_fitness = 0.0
    for generation in range(num_generations):
        # 评估适应度
        fitness = [1.0 / (1.0 + objective_function(individual, target_position)) for individual in population]

        # 排序种群
        sorted_indices = np.argsort(fitness)[::-1]
        sorted_population = [population[i] for i in sorted_indices]
        sorted_fitness = [fitness[i] for i in sorted_indices]

        # 更新最佳解
        if sorted_fitness[0] > best_fitness:
            best_fitness = sorted_fitness[0]
            best_solution = sorted_population[0]
            best_solution_generation = generation

        # 精英保留
        elite_population = sorted_population[:elite_count]
        elite_fitness = sorted_fitness[:elite_count]

        # 选择操作：轮盘赌选择，去除精英个体
        probabilities = [f / sum(sorted_fitness[elite_count:]) for f in sorted_fitness[elite_count:]]

        # 使用 random.choices 进行选择
        selected_population = random.choices(sorted_population[elite_count:],
                                             weights=probabilities,
                                             k=population_size - elite_count)

        # 交叉操作
        offspring = []
        while len(offspring) < population_size - elite_count:
            if random.random() < crossover_rate:
                parent1, parent2 = random.choices(selected_population, weights=probabilities, k=2)
                child1, child2 = multipoint_crossover(parent1, parent2, num_crossover_points)
                offspring.extend([child1, child2])

        # 变异操作
        for individual in offspring:
            for j in range(num_joints):
                if random.random() < mutation_rate:
                    # 变异
                    individual[j] += random.uniform(-0.01, 0.01)
                    # 确保角度在有效范围内
                    individual[j] = clip_angle(individual[j], params[j]['lower_limit'], params[j]['high_limit'])

        # 局部搜索
        offspring = [local_search(individual) for individual in offspring]

        # 更新种群
        population = elite_population + offspring[:population_size - elite_count]

        # 输出当前最佳解
        print(
            f"Generation {generation}: Best Fitness {sorted_fitness[0]}, Best Angles {sorted_population[0]}")

        # 调整参数
        crossover_rate, mutation_rate = adjust_parameters(crossover_rate, mutation_rate, sorted_fitness[0],
                                                          prev_best_fitness)
        prev_best_fitness = sorted_fitness[0]

    best_solution_degrees = [angle * 180 / np.pi for angle in best_solution]
    # 输出最佳解
    print("Best Solution Found:")
    print("Generation:", best_solution_generation)
    print("Joint Angles:", best_solution_degrees)
    print("Fitness:", best_fitness)
    print("End-Effector Error:", objective_function(best_solution, target_position))

    # Adaptive Simulated Annealing Parameters
    initial_temperature = 100
    cooling_factor = 0.995
    max_iterations = 10000

    # Apply Adaptive Simulated Annealing to the best solution found by the GA
    best_solution, best_fitness = adaptive_simulated_annealing(best_solution, initial_temperature, cooling_factor,
                                                               max_iterations, objective_function, target_position)
    best_solution_degrees = [angle * 180 / np.pi for angle in best_solution]

    # Output the refined best solution
    print("Refined Best Solution Found:")
    print("Joint Angles:", best_solution_degrees)
    print("Fitness:", best_fitness)
    print("End-Effector Error:", objective_function(best_solution, target_position))