import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import heapq
from matplotlib.colors import ListedColormap


# ------------------------A*算法寻找最优底座移动路径函数------------------------
class Node:
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0  # Cost from start to node
        self.h = 0  # Heuristic cost from node to goal
        self.f = 0  # Total cost

    def __lt__(self, other):
        return self.f < other.f

    def __eq__(self, other):
        return self.position == other.position


#曼哈顿距离
def heuristic(node, goal):
    # Manhattan distance heuristic
    return abs(node.position[0] - goal.position[0]) + abs(node.position[1] - goal.position[1])


# A*算法
def a_star_search(grid, start, end):
    # Initialize open and closed lists
    open_list = []
    closed_list = []

    # Create start and end nodes
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Add the start node
    heapq.heappush(open_list, start_node)

    while len(open_list) > 0:
        # Get the current node with the lowest total cost
        current_node = heapq.heappop(open_list)
        closed_list.append(current_node)

        # Check if we have reached the goal
        if current_node == end_node:
            path = []
            current = current_node
            while current is not None:
                path.append(current.position)
                current = current.parent
            return path[::-1]  # Return reversed path

        # Generate children
        (x, y) = current_node.position
        neighbors = [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]  # Adjacent squares

        for next in neighbors:
            # Check if it's within the grid boundaries
            if next[0] > (len(grid) - 1) or next[0] < 0 or next[1] > (len(grid[len(grid) - 1]) - 1) or next[1] < 0:
                continue

            # Check if it's an obstacle
            if grid[next[0]][next[1]] != 0:
                continue

            # Create a neighbor node
            new_node = Node(current_node, next)

            # Append the new node to the open list
            if new_node in closed_list:
                continue

            # Compute the tentative g value
            new_node.g = current_node.g + 1
            new_node.h = heuristic(new_node, end_node)
            new_node.f = new_node.g + new_node.h

            # Check if the node is already in the open list
            for index, item in enumerate(open_list):
                if new_node == item and new_node.g >= item.g:
                    continue

            # Add the child to the open list
            heapq.heappush(open_list, new_node)

    return None  # No path found


def plot_path(grid, path, start, end, state):
    # Define colors for different parts of the grid
    colors = {
        0: 'white',  # Free space
        1: 'black',  # Obstacle
        'path': 'blue',  # Path
        'start': 'green',  # Start point
        'end': 'red'  # End point
    }

    # Create a copy of the grid for plotting
    plot_grid = [[colors[cell] for cell in row] for row in grid]

    # Mark the start and end points
    plot_grid[start[0]][start[1]] = colors['start']
    plot_grid[end[0]][end[1]] = colors['end']

    # Create a colormap based on the color names
    color_names = list(colors.values())
    cmap = ListedColormap([plt.get_cmap('tab10')(i) for i in range(len(color_names))])

    # Convert the color names to RGBA values
    plot_grid_rgba = [[plt.get_cmap('tab10')(color_names.index(color)) for color in row] for row in plot_grid]

    # Plot the grid using the colormap
    plt.imshow(plot_grid_rgba, cmap=cmap, origin='lower')

    # Plot the path as a line
    if path:
        xs, ys = zip(*path)
        plt.plot(ys, xs, color=colors['path'], linewidth=2)

    plt.grid(True)
    if state == 0:
        plt.title("Go path")
        plt.savefig('Q3_go_path.png')
    else:
        plt.title("Back path")
        plt.savefig('Q3_back_path.png')

    plt.show()


# ------------------------寻找最优关节角路径函数------------------------
# 计算变换矩阵,传统D-H法
def standard_calc_transform_matrix(param):
    theta, d, a, alpha = param['theta'], param['d'], param['a'], param['alpha']

    return np.array([[np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
                     [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
                     [0, np.sin(alpha), np.cos(alpha), d],
                     [0, 0, 0, 1]])


# 目标函数：计算末端位置与目标位置之间的欧几里得距离和能耗
def objective_function(angles, target_position):
    T = np.eye(4)
    energy_consumption = gravitational_potential
    for i, param in enumerate(params[1:], start=1):
        param['theta'] = angles[i - 1]
        T = T @ standard_calc_transform_matrix(param)
        energy_consumption += 0.5 * param['I'] * param['omega'] ** 2
    end_effector_position = T[:3, 3]
    position_error = np.linalg.norm(end_effector_position - target_position)
    if position_error > 200:
        position_error = 200  # 误差阈值处理
    # 动态调整能量权重
    energy_weight = 0.01 + 0.001 * max(0, 200 - position_error) / 200
    total_error = position_error + energy_weight * energy_consumption
    return float(total_error)


# 辅助函数：确保角度在给定的范围内
def clip_angle(theta, lower_limit, high_limit):
    # 确保角度在给定的范围内
    return max(lower_limit, min(high_limit, theta))


# 局部搜索：梯度下降
def local_search(individual, learning_rate=0.01, iterations=100):
    for _ in range(iterations):
        gradient = np.zeros_like(individual)
        for i in range(len(individual)):
            epsilon = 1e-16
            individual_plus = individual.copy()
            individual_plus[i] += epsilon
            individual_minus = individual.copy()
            individual_minus[i] -= epsilon
            gradient[i] = (objective_function(individual_plus, target_position) -
                           objective_function(individual_minus, target_position)) / (2 * epsilon)

        # 更新个体
        individual -= learning_rate * gradient
        # 确保角度在有效范围内
        for i in range(len(individual)):
            individual[i] = clip_angle(individual[i], params[i]['lower_limit'], params[i]['high_limit'])
    return individual


# 多点交叉
def multipoint_crossover(parent1, parent2, num_points=2):
    crossover_points = sorted(random.sample(range(1, len(parent1)), num_points))
    child1, child2 = parent1.copy(), parent2.copy()

    for i in range(num_points):
        start = crossover_points[i]
        end = crossover_points[(i + 1) % num_points] if i < num_points - 1 else len(parent1)
        child1[start:end], child2[start:end] = child2[start:end], child1[start:end]
    return child1, child2


# 定义用于调整参数的函数
def adjust_parameters(crossover_rate, mutation_rate, best_fitness, prev_best_fitness):
    improvement_threshold = 0.01  # 改善阈值
    diversity_threshold = 0.01  # 多样性阈值

    # 检查是否有显著改善
    if best_fitness > prev_best_fitness + improvement_threshold:
        mutation_rate *= 0.9  # 减少变异率
    else:
        mutation_rate *= 1.1  # 增加变异率

    # 检查种群多样性
    if mutation_rate > 0.5:
        crossover_rate *= 0.9  # 减少交叉率
    else:
        crossover_rate *= 1.1  # 增加交叉率

    # 限制参数范围
    crossover_rate = max(min(crossover_rate, 1.0), 0.0)
    mutation_rate = max(min(mutation_rate, 1.0), 0.0)

    return crossover_rate, mutation_rate


# 定义模拟退火算法
def adaptive_simulated_annealing(initial_solution, initial_temperature, cooling_factor, max_iterations,
                                 objective_function, target_position, improvement_threshold=0.001,
                                 diversity_threshold=0.01):
    current_solution = initial_solution
    current_fitness = objective_function(current_solution, target_position)
    best_solution = current_solution
    best_fitness = current_fitness

    temperature = initial_temperature
    prev_best_fitness = best_fitness

    for iteration in range(max_iterations):
        # Generate a new candidate solution
        candidate_solution = current_solution + np.random.uniform(-0.01, 0.01, size=len(current_solution))
        for i in range(len(candidate_solution)):
            candidate_solution[i] = clip_angle(candidate_solution[i], params[i]['lower_limit'], params[i]['high_limit'])

        candidate_fitness = objective_function(candidate_solution, target_position)

        # Calculate the change in fitness
        delta_fitness = candidate_fitness - current_fitness

        # Acceptance probability
        if delta_fitness < 0 or np.exp(-delta_fitness / temperature) > np.random.rand():
            current_solution = candidate_solution
            current_fitness = candidate_fitness

            # Update the best solution
            if current_fitness < best_fitness:
                best_solution = current_solution
                best_fitness = current_fitness
                prev_best_fitness = best_fitness

        # Adaptive cooling
        if best_fitness > prev_best_fitness + improvement_threshold:
            cooling_factor *= 0.09  # Faster cooling
        elif temperature > diversity_threshold:
            cooling_factor *= 1.01  # Slower cooling

        # Cool down the temperature
        temperature *= cooling_factor

    return best_solution, best_fitness


if __name__ == '__main__':
    # ------------------------寻找最优底座移动路径------------------------
    df = pd.read_excel('附件.xlsx', sheet_name='Sheet1')
    grid = []
    start = (0, 0)
    end = (0, 0)
    for i in range(len(df)):
        grid.append(df.iloc[i].tolist())

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == "Start":
                start = (i, j)
                grid[i][j] = 0
            if grid[i][j] == "End":
                end = (i, j)
                grid[i][j] = 0

    path = a_star_search(grid, start, end)
    print("Path:", path)
    plot_path(grid, path, start, end, 0)

    # 回到起点
    start, end = end, start
    path = a_star_search(grid, start, end)
    print("BackPath:", path)
    plot_path(grid, path, start, end, 1)

    # ------------------------寻找最优关节角路径------------------------
    # 定义连杆参数
    params = [
        {'a': 0,   'alpha': 0,          'd': 600, 'theta': 0,          'lower_limit': -np.pi*160/180, 'high_limit': np.pi*160/180, 'I': 0.5, 'omega': 2.0},  # 连杆1
        {'a': 300, 'alpha': -np.pi / 2, 'd': 0,   'theta': -np.pi / 2, 'lower_limit': -np.pi*150/180, 'high_limit': np.pi*15/180,  'I': 0.3, 'omega': 1.5},  # 连杆2
        {'a': 1200,'alpha': 0,          'd': 0,   'theta': 0,          'lower_limit': -np.pi*200/180, 'high_limit': np.pi*80/180,  'I': 0.4, 'omega': 1.0},  # 连杆3
        {'a': 300, 'alpha': -np.pi / 2, 'd': 1200,'theta': np.pi,      'lower_limit': -np.pi*180/180, 'high_limit': np.pi*180/180, 'I': 0.6, 'omega': 2.5},  # 连杆4
        {'a': 0,   'alpha': -np.pi / 2, 'd': 0,   'theta': -np.pi / 2, 'lower_limit': -np.pi*120/180, 'high_limit': np.pi*120/180, 'I': 0.2, 'omega': 3.0},  # 连杆5
        {'a': 0,   'alpha': -np.pi / 2, 'd': 0,   'theta': 0,          'lower_limit': -np.pi*180/180, 'high_limit': np.pi*180/180, 'I': 0.4, 'omega': 2.0}   # 连杆6
    ]
    target_position = np.array([1500, 1200, 200])
    num_joints = len(params)

    # 初始化变换矩阵
    T = np.eye(4)
    T_i=np.eye(4) @ standard_calc_transform_matrix({'a': 0, 'alpha': 0, 'd': 0, 'theta': 0  })
    for param in params:
        T_i = T_i @ standard_calc_transform_matrix(param)
    end_position = T_i[:3, 3]
    change_h=(end_position[2]-target_position[2])/1000
    M = 5
    g = 10
    gravitational_potential= M * g * change_h

    # 自适应遗传算法
    # 遗传算法参数
    population_size = 100
    num_generations = 50
    crossover_rate = 0.8
    mutation_rate = 0.1
    elite_count = 2  # 精英个体的数量
    num_crossover_points = 2  # 多点交叉的点数

    # 初始化种群
    population = [
        [clip_angle(np.random.uniform(params[i]['lower_limit'], params[i]['high_limit']),
                    params[i]['lower_limit'], params[i]['high_limit'])
         for i in range(num_joints)]
        for _ in range(population_size)
    ]

    # 初始化变量用于记录最佳解
    best_solution = None
    best_fitness = float('-inf')
    best_solution_generation = 0

    # 遗传算法主循环
    prev_best_fitness = 0.0
    for generation in range(num_generations):
        # 评估适应度
        fitness = [1.0 / (1.0 + objective_function(individual, target_position)) for individual in population]

        # 排序种群
        sorted_indices = np.argsort(fitness)[::-1]
        sorted_population = [population[i] for i in sorted_indices]
        sorted_fitness = [fitness[i] for i in sorted_indices]

        # 更新最佳解
        if sorted_fitness[0] > best_fitness:
            best_fitness = sorted_fitness[0]
            best_solution = sorted_population[0]
            best_solution_generation = generation

        # 精英保留
        elite_population = sorted_population[:elite_count]
        elite_fitness = sorted_fitness[:elite_count]

        # 选择操作：轮盘赌选择，去除精英个体
        probabilities = [f / sum(sorted_fitness[elite_count:]) for f in sorted_fitness[elite_count:]]

        # 使用 random.choices 进行选择
        selected_population = random.choices(sorted_population[elite_count:],
                                             weights=probabilities,
                                             k=population_size - elite_count)

        # 交叉操作
        offspring = []
        while len(offspring) < population_size - elite_count:
            if random.random() < crossover_rate:
                parent1, parent2 = random.choices(selected_population, weights=probabilities, k=2)
                child1, child2 = multipoint_crossover(parent1, parent2, num_crossover_points)
                offspring.extend([child1, child2])

        # 变异操作
        for individual in offspring:
            for j in range(num_joints):
                if random.random() < mutation_rate:
                    # 变异
                    individual[j] += random.uniform(-0.01, 0.01)
                    # 确保角度在有效范围内
                    individual[j] = clip_angle(individual[j], params[j]['lower_limit'], params[j]['high_limit'])

        # 局部搜索
        offspring = [local_search(individual) for individual in offspring]

        # 更新种群
        population = elite_population + offspring[:population_size - elite_count]

        # 输出当前最佳解
        print(
            f"Generation {generation}: Best Fitness {sorted_fitness[0]}, Best Angles {sorted_population[0]}")

        # 调整参数
        crossover_rate, mutation_rate = adjust_parameters(crossover_rate, mutation_rate, sorted_fitness[0],
                                                          prev_best_fitness)
        prev_best_fitness = sorted_fitness[0]

    best_solution_degrees = [angle * 180 / np.pi for angle in best_solution]

    # 输出最佳解
    print("Best Solution Found:")
    print("Generation:", best_solution_generation)
    print("Joint Angles:", best_solution_degrees)
    print("Fitness:", best_fitness)
    print("End-Effector Error:", objective_function(best_solution, target_position))

    # Adaptive Simulated Annealing Parameters
    initial_temperature = 100
    cooling_factor = 0.995
    max_iterations = 10000
    # Apply Adaptive Simulated Annealing to the best solution found by the GA
    best_solution, best_fitness = adaptive_simulated_annealing(best_solution, initial_temperature, cooling_factor,
                                                               max_iterations, objective_function, target_position)
    best_solution_degrees = [angle * 180 / np.pi for angle in best_solution]

    # Output the refined best solution
    print("Refined Best Solution Found:")
    print("Joint Angles:", best_solution_degrees)
    print("Fitness:", best_fitness)
    print("End-Effector Error:", objective_function(best_solution, target_position))
