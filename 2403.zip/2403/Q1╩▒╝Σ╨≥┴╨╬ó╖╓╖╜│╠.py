import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import r2_score


# 定义拟合微分函数模型
def modelFuction(x, C1, V2, C2):
    return C1 * np.exp(-(V2 / 44.3) * x) + C2 / V2

# 读取数据
df=pd.read_excel("表1.xlsx")
x=np.array([i for i in range(1,len(df.index.values)+1)])
args=[]

for i in range(len(df.columns[1:])):
    lst=df[df.columns[1:][i]].values

    # 使用curve_fit进行拟合
    pop, pov = curve_fit(modelFuction, x, lst)

    # 保存参数至列表
    args.append(pop)
    # 输出拟合得到的参数值
    print("监测点{} C₁: {:.5f}, V₂: {:.5f}, C: {:.5f}".format(i+1, pop[0], pop[1], pop[2]))

    # 计算拟合值
    y_fit = modelFuction(x, *pop)

    # 计算R^2分数
    r2 = r2_score(lst, y_fit)
    print("监测点{} R^2 score: {:.5f}".format(i+1, r2))

    # 绘制数据和拟合曲线
    plt.figure(figsize=(8, 4))
    plt.scatter(x, lst, label='Data')
    plt.plot(x, y_fit, 'r-', label='Fit: $y = C₁ \cdot e^{-V₂x/44.3} + C/V₂$')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.savefig(f"监测点 {i + 1}.png")
    plt.show()

    # 预测第20周和第30周的太湖污染物浓度
    print(f"监测点{i + 1} 第 20 周的污染物浓度:", round(modelFuction(20, *pop), 5))
    print(f"监测点{i + 1} 第 30 周的污染物浓度:", round(modelFuction(30, *pop), 5))

# 保存模型参数
pd.DataFrame(args, index=df.columns[1:], columns=["C₁", "V₂", "C"]).to_excel("题1模型参数.xlsx")