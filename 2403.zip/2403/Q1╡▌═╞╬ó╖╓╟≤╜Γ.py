from scipy.optimize import differential_evolution
import numpy as np
import pandas as pd


# 递推模型方程
def modelFuction(pre, x, y, z):
    return (pre - x * y / (z - y)) * np.exp(-7 * z / 44.3) + x * y / (z - y)


# 递推预测
def recursion(list, vars):
    results = [modelFuction(list[-1], *vars)]
    for i in range(15):
        results.append(modelFuction(results[-1], *vars))
    return results


# 列表平均值函数
def average_excluding_extremes(nums):
    max_val = max(nums)
    min_val = min(nums)
    filtered_nums = [num for num in nums if num != max_val and num != min_val]
    average = sum(filtered_nums) / len(filtered_nums)
    return average


if __name__ == '__main__':
    # 读取数据
    df = pd.read_excel("表1.xlsx")
    c1, v1, v2 = [], [], []

    # 遍历监测点求解
    for i in range(len(df.columns[1:])):
        list = df[df.columns[1:][i]].values.tolist()
    
        # 方程组
        def equations(vars):
            x, y, z = vars
            results = []
            for i in range(len(list) - 1):
                eq = (list[i] - x * y / (z - y)) * np.exp(-7 * z / 44.3) + x * y / (z - y) - list[i + 1]
                results.append(eq)
            return np.sum(np.array(results) ** 2)


        # 边界条件
        bounds = [(10, 30), (0, 10), (0, 100)]

        # 使用differential_evolution求解方程组
        result = differential_evolution(equations, bounds, maxiter=10000000, tol=1e-9)

        # result.x包含了参数最优解
        solution = result.x
        print("Solution:", solution)
        print("最小误差:", result.fun)

        predict = recursion(list, solution)
        c1.append(solution[0])
        v1.append(solution[1])
        v2.append(solution[2])
        print(predict)

    # 求参数平均值
    c1_mean = average_excluding_extremes(c1)
    v1_mean = average_excluding_extremes(v1)
    v2_mean = average_excluding_extremes(v2)
    print("-----------------------------------")
    print("综上所述：")
    print(f"c1={round(c1_mean, 5)},v1={round(v1_mean, 5)},v2={round(v2_mean, 5)}")
    for i in range(len(df.columns[1:])):
        list = df[df.columns[1:][i]].values.tolist()
        predict = recursion(list, [c1_mean, v1_mean, v2_mean])
        print(f"监测点{i + 1} 第 20 周的污染物浓度:", round(predict[4], 5))
        print(f"监测点{i + 1} 第 30 周的污染物浓度:", round(predict[14], 5))