import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 读取数据
df = pd.read_excel("题1模型参数.xlsx")
df1 = pd.read_excel("表2.xlsx")
args, args_copy, c_start, data_orig, data_changed, percentage, points, week, number = [], [], [], [], [], [], [], df1["监测时间"].tolist(), df1["预估数量"].tolist()     #c_start：太湖初始污染物浓度
c_orig, c_change, v_in, adsorb_ratio, decompose_ratio = 25, 5, 1, 0.25, 0.03
V = 44.3  #太湖容量

# 时间序列微分模型方程
def time_series_model(x, C1, V2, C2):
    return C1 * np.exp(-(V2 / V) * x) + C2 / V2

# 递推微分模型方程
def recursive_model(Cn, V2, M1):
    return (Cn - M1 / V2) * np.exp(-(V2 / V)) + M1 / V2

# 改良递推微分模型方程
def improved_recursive_model(Cn, V2, M1, num):
    return (Cn - M1 / (V2 + decompose_ratio * num * V)) * np.exp(-((V2 / V) + decompose_ratio * num)) + M1 / (V2 + decompose_ratio * num * V)

for i in range(len(df.index)):
    points.append(df.iloc[i].values[0])
    args.append(df.iloc[i].values[1:].tolist())
    c_start.append(time_series_model(0, *args[-1]))
    args[-1][0] = c_start[-1]
    args[-1][2] = c_orig * v_in
args_copy = args.copy()

# 原始浓度
for i in range(len(c_start)):
    point = []
    for j in range(15):
        point.append(recursive_model(*args_copy[i]))
        args_copy[i][0] = point[-1]
    data_orig.append(point)
print(data_orig)
pd.DataFrame(data_orig, index=points, columns=week).to_excel("题3前15周原始浓度数据.xlsx")

# 综合措施下参数
for i in range(len(args)):
    args[i][0] = c_start[i]
    args[i][2] = c_change * v_in * (1 - adsorb_ratio)
args_copy = args.copy()

# 综合措施下浓度
for i in range(len(c_start)):
    point = []
    for j in range(15):
        point.append(improved_recursive_model(*args_copy[i], number[j]))
        args_copy[i][0] = point[-1]
    data_changed.append(point)
print(data_changed)
pd.DataFrame(data_changed, index=points, columns=week).to_excel("题3前15周综合措施下浓度数据.xlsx")

# 可视化数据
plt.rc("font", family='Microsoft YaHei')
for i in range(len(data_orig)):
    plt.figure(figsize=(15, 10))
    plt.scatter(["初始浓度"]+week, [c_start[i]]+data_orig[i], label='Original concentration data')
    plt.plot(["初始浓度"]+week, [c_start[i]]+data_orig[i], 'r-', label="Original concentration")
    plt.scatter(["初始浓度"]+week, [c_start[i]]+data_changed[i], label='Concentration data under comprehensive measures')
    plt.plot(["初始浓度"]+week, [c_start[i]]+data_changed[i], 'b-', label="Concentration under comprehensive measures")
    plt.xlabel('x')
    plt.ylabel('c')
    plt.title(f'监测点{i+1}浓度变化图')
    plt.legend()
    plt.savefig(f"3.监测点 {i + 1}.png")
    plt.show()

# 下降比例
for i in range(len(data_changed)):
    per = []
    for j in range(len(data_changed[i])):
        per.append(100 * np.abs(data_changed[i][j] - data_orig[i][j]) / data_orig[i][j])
    percentage.append(per)
print(percentage)
pd.DataFrame(percentage, index=points, columns=week).to_excel("题3前15周浓度下降比例(%).xlsx")