import numpy as np
import pandas as pd
import scipy.stats as stats
import matplotlib.pyplot as plt
from skopt import BayesSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.svm import SVR
from statsmodels.tsa.stattools import acf


"""
    ：使用贝叶斯优化随机森林模型进行时间序列预测
"""


dayforecast={"分拣中心":[], "日期":[], "货量":[]}
hourforecast={"分拣中心":[], "日期":[], "小时":[], "货量":[]}
de={"name":[],"mse":[],"mae":[]}
he={"name":[],"mse":[],"mae":[]}

# 白噪音检验和异常值替换
def detect_and_replace_outliers(data):
    # 计算自相关系数
    acf_values = acf(data, nlags=len(data) // 2)
    # 根据置信水平选择合适的 z 分数
    confidence_level = 0.90
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    # 检查是否为白噪声
    is_white_noise = all(abs(value) < z_score / np.sqrt(len(data)) for value in acf_values[1:])

    if not is_white_noise:
        # 使用SVR进行异常值检测与替换
        svr = SVR(kernel='rbf', C=1e3, gamma=0.1)
        # 使用除当前点外的所有点来预测当前点
        X = np.arange(len(data)).reshape(-1, 1)
        y = data

        svr.fit(X[:-1], y[:-1])
        predictions = svr.predict(X[1:])

        # 替换异常值
        for i in range(1, len(data)):
            if abs(y[i] - predictions[i - 1]) > 2 * np.std(y):
                y[i] = predictions[i - 1]

    return y

#SVR替换缺失值
def fill_missing_data_with_svr(df):
    # 创建完整的日期时间索引
    date_rng = pd.date_range(start=f"{df['datetime'].min().floor('D')} 00:00", end=f"{df['datetime'].max().floor('D')} 23:00", freq='H')
    full_index = pd.DataFrame(index=date_rng)
    df = df.set_index('datetime').reindex(full_index.index).reset_index().rename(columns={'index': 'datetime'})

    # 仅选择需要填充的列
    df = df[['datetime', '货量']]

    # 检查是否存在缺失值
    if df['货量'].isnull().any():
        # 使用SVR填充缺失值
        not_null_indices = df['货量'].notnull()
        X = df.loc[not_null_indices, 'datetime'].values.reshape(-1, 1)
        y = df.loc[not_null_indices, '货量'].values

        # 数据标准化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X.astype(float))

        # 训练SVR模型
        svr = SVR(kernel='rbf', C=1e3, gamma=0.1)
        svr.fit(X_scaled, y)

        # 预测缺失值
        missing_indices = ~df['货量'].notnull()
        X_missing = df.loc[missing_indices, 'datetime'].values.reshape(-1, 1)
        X_missing_scaled = scaler.transform(X_missing.astype(float))
        y_missing_pred = svr.predict(X_missing_scaled)

        # 替换缺失值
        df.loc[missing_indices, '货量'] = y_missing_pred
    else:
        # 如果没有缺失值，则直接返回原始数据集
        pass

    return df

# 创建时间序列数据集
def create_dataset(dataset, look_back=1):
    dataX, dataY = [], []
    for i in range(len(dataset)-look_back-1):
        a = dataset[i:(i+look_back), 0]
        dataX.append(a)
        dataY.append(dataset[i + look_back, 0])
    return np.array(dataX), np.array(dataY)

# 多步预测函数
def multi_step_forecast(scaler, model, scaled_data, forecast_steps, look_back):
    forecast_result = []
    last_window = scaled_data[-look_back:]
    for _ in range(forecast_steps):
        # 预测下一个时间步
        next_step = model.predict(last_window.reshape(1, -1))
        # 将预测结果添加到结果列表
        forecast_result.append(next_step[0])
        # 更新窗口
        last_window = np.roll(last_window, -1)
        last_window[-1] = next_step
    return scaler.inverse_transform(np.array(forecast_result).reshape(-1, 1))

# ----------------定义随机森林预测模型----------------
def RandomForest_model_D(df, dfname, forecast_steps):
    # 缩放数据
    scaler = MinMaxScaler(feature_range=(0, 1))

    # 异常值处理
    cleaned_data = detect_and_replace_outliers(df["货量"].values)
    scaled_data = scaler.fit_transform(cleaned_data.reshape(-1, 1))

    # 数据预处理
    look_back = 30
    X, Y = create_dataset(scaled_data, look_back)

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

    # 定义随机森林模型
    rf = RandomForestRegressor(random_state=42)

    # 定义参数分布
    param_distributions = {
        'n_estimators': (100, 300),
        'max_depth': (10, 50),
        'min_samples_split': (2, 10),
        'min_samples_leaf': (1, 10),
        'max_features': ['auto', 'sqrt']
    }

    # 使用 BayesSearchCV 执行参数搜索
    bayes_search = BayesSearchCV(
        estimator=rf,
        search_spaces=param_distributions,
        n_iter=40,  # 搜索迭代次数
        cv=5,       # 交叉验证折数
        scoring='neg_mean_squared_error',  # 优化的目标
        n_jobs=1,  # 并行任务数量
        verbose=2  # 输出详细信息
    )
    bayes_search.fit(X_train, y_train)

    # 获取最佳参数
    best_params = bayes_search.best_params_
    print("Best parameters:", best_params)

    # 使用最佳参数重新训练模型
    best_rf = RandomForestRegressor(**best_params, random_state=42)
    best_rf.fit(X_train, y_train)

    # 在测试集上进行预测以评估模型性能
    y_test_pred = best_rf.predict(X_test)

    # 反缩放预测结果
    y_test_pred_unscaled = scaler.inverse_transform(y_test_pred.reshape(-1, 1))
    y_test_unscaled = scaler.inverse_transform(y_test.reshape(-1, 1))

    # 计算测试集上的误差
    mse_train = mean_squared_error(y_test_unscaled, y_test_pred_unscaled)
    mae_train = mean_absolute_error(y_test_unscaled, y_test_pred_unscaled)
    de["name"].append(dfname)
    de["mse"].append(mse_train)
    de["mae"].append(mae_train)
    print(f"Training MSE: {mse_train}")
    print(f"Training MAE: {mae_train}")

    # 绘制模型对原始数据拟合效果的折线图
    plt.figure(figsize=(14, 7))
    plt.plot(y_test_unscaled, label='Actual Test Data', color='blue')
    plt.plot(y_test_pred_unscaled, label='Predicted Test Data', color='green')
    plt.title(f'{dfname} Model Fit on Test Data')
    plt.xlabel('Time Step')
    plt.ylabel('Value')
    plt.legend()
    plt.savefig(f"F:\\Python数模\\暑期培训\\2406\\Q113\\Q12 {dfname} Model Fit on Test Data.png")
    plt.show()

    # 预测未来30天的数据
    forecast_result_original = multi_step_forecast(scaler, best_rf, scaled_data, forecast_steps, look_back)
    forecast_result_o = [forecast_result_original[i][0] for i in range(len(forecast_result_original))]
    for i in range(len(forecast_result_o)):
        if forecast_result_o[i] < 0:
            forecast_result_o[i] = 0
    dayforecast["货量"].extend(forecast_result_o)
    dayforecast["分拣中心"].extend([dfname]*len(forecast_result_o))

    # 绘制原始数据的时间序列图
    plt.figure(figsize=(14, 7))
    plt.plot(df["日期"], df["货量"], label='Original Data', color='blue')

    # 将预测数据转换为DataFrame并添加到原始DataFrame中
    forecast_df = pd.DataFrame(forecast_result_original, columns=['Forecast'])
    forecast_df['datetime'] = pd.date_range(start=df["日期"].iloc[-1] + pd.Timedelta(days=1), periods=len(forecast_df), freq='1D')
    dayforecast["日期"].extend(list(pd.to_datetime(forecast_df['datetime']).dt.date.replace("-", "/")))

    # 绘制预测数据的时间序列图
    plt.plot(forecast_df['datetime'], forecast_df['Forecast'], label='Forecast', color='red')

    # 设置图表标题和图例
    plt.title(f'{dfname} Time Series 30 Days Forecast')
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.savefig(f"F:\\Python数模\\暑期培训\\2406\\Q113\\Q11 {dfname} Time Series 30 Days Forecast.png")
    plt.legend()

    # 显示图表
    plt.show()


def RandomForest_model_H(df, dfname, forecast_steps):
    # 填充缺失值
    df = fill_missing_data_with_svr(df)

    # 缩放数据
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df["货量"].values.reshape(-1, 1))

    # 数据预处理
    look_back = 30
    X, Y = create_dataset(scaled_data, look_back)

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

    # 定义随机森林模型
    rf = RandomForestRegressor(random_state=42)

    # 定义参数分布
    param_distributions = {
        'n_estimators': (100, 300),
        'max_depth': (10, 50),
        'min_samples_split': (2, 10),
        'min_samples_leaf': (1, 6),
        'max_features': ['auto', 'sqrt']
    }

    # 使用 BayesSearchCV 执行参数搜索
    bayes_search = BayesSearchCV(
        estimator=rf,
        search_spaces=param_distributions,
        n_iter=40,  # 搜索迭代次数
        cv=5,       # 交叉验证折数
        scoring='neg_mean_squared_error',  # 优化的目标
        n_jobs=1,  # 并行任务数量
        verbose=2  # 输出详细信息
    )
    bayes_search.fit(X_train, y_train)

    # 获取最佳参数
    best_params = bayes_search.best_params_
    print("Best parameters:", best_params)

    # 使用最佳参数重新训练模型
    best_rf = RandomForestRegressor(**best_params, random_state=42)
    best_rf.fit(X_train, y_train)

    # 在测试集上进行预测以评估模型性能
    y_test_pred = best_rf.predict(X_test)

    # 反缩放预测结果
    y_test_pred_unscaled = scaler.inverse_transform(y_test_pred.reshape(-1, 1))
    y_test_unscaled = scaler.inverse_transform(y_test.reshape(-1, 1))

    # 计算测试集上的误差
    mse_train = mean_squared_error(y_test_unscaled, y_test_pred_unscaled)
    mae_train = mean_absolute_error(y_test_unscaled, y_test_pred_unscaled)
    he["name"].append(dfname)
    he["mse"].append(mse_train)
    he["mae"].append(mae_train)
    print(f"Training MSE: {mse_train}")
    print(f"Training MAE: {mae_train}")

    # 绘制模型对原始数据拟合效果的折线图
    plt.figure(figsize=(14, 7))
    plt.plot(y_test_unscaled, label='Actual Test Data', color='blue')
    plt.plot(y_test_pred_unscaled, label='Predicted Test Data', color='green')
    plt.title(f'{dfname} Model Fit on Test Data')
    plt.xlabel('Time Step')
    plt.ylabel('Value')
    plt.legend()
    plt.savefig(f"F:\\Python数模\\暑期培训\\2406\\Q114\\Q12 {dfname} Model Fit on Test Data.png")
    plt.show()

    # 预测未来30天每小时的数据
    forecast_result_original = multi_step_forecast(scaler, best_rf , scaled_data, forecast_steps, look_back)
    # 整理数据，小于0的变为0
    for i in range(len(forecast_result_original)):
        if forecast_result_original[i][0]<0:
            forecast_result_original[i][0]=0

    forecast_result_o=[forecast_result_original[i][0] for i in range(len(forecast_result_original))]
    hourforecast["货量"].extend(forecast_result_o)
    hourforecast["分拣中心"].extend([dfname] * len(forecast_result_o))

    # 绘制原始数据的时间序列图
    plt.figure(figsize=(14, 7))
    plt.plot(df['datetime'], df["货量"], label='Original Data', color='blue')

    # 将预测数据转换为DataFrame并添加到原始DataFrame中
    forecast_df = pd.DataFrame(forecast_result_original, columns=['Forecast'])
    forecast_df ['datetime'] = pd.date_range(start=df['datetime'].iloc[-1] + pd.Timedelta(hours=1), periods=len(forecast_df), freq='1H')
    hourforecast["日期"].extend(list(pd.to_datetime(forecast_df['datetime']).dt.date.replace("-", "/")))
    hourforecast["小时"].extend(list(pd.to_datetime(forecast_df['datetime']).dt.hour))

    # 绘制预测数据的时间序列图
    plt.plot(forecast_df['datetime'], forecast_df['Forecast'], label='Forecast', color='red')

    # 设置图表标题和图例
    plt.title(f'{dfname} Time Series 720 Hours Forecast')
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.savefig(f"F:\\Python数模\\暑期培训\\2406\\Q114\\Q12 {dfname} Time Series 720 Hours Forecast.png")
    plt.legend()

    # 显示图表
    plt.show()

# ----------------预测30天数据----------------
df_day=pd.read_csv("F:\\Python数模\\暑期培训\\2406\\附件\\附件1.csv", encoding='GBK')
df_day["日期"] = pd.to_datetime(df_day["日期"])
df_day=df_day.groupby("分拣中心").apply(lambda x: x.sort_values('日期')).reset_index(drop=True)
groupnamed=list(df_day.groupby("分拣中心").groups.keys())
# 预测每个分拣中心30天数据
for i in groupnamed:
    df_group=df_day[df_day["分拣中心"] == i]
    RandomForest_model_D(df_group, i, 30)

# 保存预测30天数据
pd.DataFrame(dayforecast).to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表1.csv", index=False, encoding='GBK')
pd.DataFrame(de).to_csv("Q11day误差.csv", index=False)


# ----------------预测30天每小时数据----------------
df_hour=pd.read_csv("F:\\Python数模\\暑期培训\\2406\\附件\\附件2.csv", encoding='GBK')
df_hour['datetime'] = df_hour.apply(lambda row: pd.to_datetime(f"{row['日期']} {row['小时']}:00"), axis=1)
df_hour=df_hour.groupby("分拣中心").apply(lambda x: x.sort_values('datetime')).reset_index(drop=True)
groupnameh=list(df_hour.groupby("分拣中心").groups.keys())
# 预测每个分拣中心30天每小时数据
for i in groupnameh:
    df1_group=df_hour[df_hour["分拣中心"] == i]
    RandomForest_model_H(df1_group, i, 720)

# 保存预测30天每小时数据
pd.DataFrame(hourforecast).to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表2.csv", index=False, encoding='GBK')
pd.DataFrame(he).to_csv("Q11hour误差.csv", index=False)