import pulp
import pandas as pd
from multiprocessing import Pool


# 混合整数模型
def model_day(df, regular_workers, max_regular_shifts=6, max_consecutive_days=7):
    worker_energy = {'Regular': 25, 'Temp': 20}
    package_demands = df["货量"].values.tolist()
    flag = [
        [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1]
    ]

    # 创建问题实例
    prob = pulp.LpProblem("Package_Processing_Scheduling", pulp.LpMinimize)

    # 定义变量
    x_vars = [pulp.LpVariable(f"正式工班次{i}", lowBound=0, cat='Integer') for i in range(1, 7)]
    y_vars = [pulp.LpVariable(f"临时工班次{i}", lowBound=0, cat='Integer') for i in range(1, 7)]
    regular_days = [pulp.LpVariable(f"正式工出勤天数{i}", lowBound=22, upBound=25, cat='Integer') for i in range(regular_workers)]  # 出勤天数限制
    regular_shifts = [[pulp.LpVariable(f"正式工{i}_班次{j}", lowBound=0, upBound=1, cat='Binary') for j in range(1, 7)] for i in range(regular_workers)]
    regular_shift_counts = [pulp.LpVariable(f"正式工{i}_班次数", lowBound=0, upBound=max_regular_shifts, cat='Integer') for i in range(regular_workers)]

    # 计算每小时的人效
    hour_efficiency = [worker_energy["Regular"] * sum(sum(x * f[i] for x, f in zip(worker_shifts, flag)) for worker_shifts in regular_shifts) + worker_energy["Temp"] * sum(y * f[i] for y, f in zip(y_vars, flag)) for i in range(24)]
    total_efficiency = pulp.lpSum(worker_energy["Regular"] * sum(sum(x * f[i] for x, f in zip(worker_shifts, flag)) for worker_shifts in regular_shifts) for i in range(24))
    avg_efficiency = pulp.lpSum(hour_efficiency) / 24

    # 效率差异
    efficiency_diff_abs = pulp.LpVariable.dicts("EfficiencyDiffAbs", range(24), lowBound=0, cat='Continuous')
    M = 1000

    # 效率差异约束
    for i in range(24):
        diff = hour_efficiency[i] - avg_efficiency
        abs_diff_var = pulp.LpVariable(f"AbsDiff_{i}", lowBound=0, cat='Continuous')
        binary_var = pulp.LpVariable(f"Binary_{i}", lowBound=0, upBound=1, cat='Binary')
        prob += abs_diff_var >= diff - M * (1 - binary_var)
        prob += abs_diff_var <= diff + M * binary_var
        prob += efficiency_diff_abs[i] == abs_diff_var

    # 工作天数差异
    avg_days = pulp.lpSum(regular_days) / regular_workers
    days_diff_abs = pulp.LpVariable.dicts("DaysDiffAbs", range(regular_workers), lowBound=0, cat='Continuous')
    for i in range(regular_workers):
        diff = regular_days[i] - avg_days
        abs_diff_var = pulp.LpVariable(f"AbsDiffDays_{i}", lowBound=0, cat='Continuous')
        binary_var = pulp.LpVariable(f"BinaryDays_{i}", lowBound=0, upBound=1, cat='Binary')
        prob += abs_diff_var >= diff - M * (1 - binary_var)
        prob += abs_diff_var <= diff + M * binary_var
        prob += days_diff_abs[i] == abs_diff_var

    # 总出勤天数
    total_days = pulp.lpSum(regular_days)

    # 添加正式工出勤总人数的约束
    prob += (total_days >= 4000)
    prob += (total_days <= 5000)

    # 修改目标函数：最大化正式工的数量，最小化临时工的数量，并最小化正式工和临时工的总工作天数
    prob += (-100000 * pulp.lpSum(x_vars) + 10000 * pulp.lpSum(y_vars) + 1000 * pulp.lpSum(regular_days) + 1000 * pulp.lpSum(y_vars))
    
    # 确保所有正式工都出勤
    for i in range(regular_workers):
        prob += (regular_days[i] >= 22)  # 正式工出勤天数下限
        prob += (regular_days[i] <= 25)  # 正式工出勤天数上限

    # 其他约束条件
    for i in range(24):
        prob += ( (worker_energy["Regular"] * sum(sum(x * f[i] for x, f in zip(worker_shifts, flag)) for worker_shifts in regular_shifts) + worker_energy["Temp"] * sum(y * f[i] for y, f in zip(y_vars, flag))) >= package_demands[i])

    prob += (pulp.lpSum(x_vars) <= max_regular_shifts)

    # **确保正式工优先调度**：通过约束确保正式工尽可能被使用
    for i in range(regular_workers):
        prob += (regular_days[i] <= max_consecutive_days)
        prob += (sum(regular_shifts[i]) <= 1)
        prob += (regular_shift_counts[i] == sum([regular_shifts[i][j - 1] for j in range(1, 7)]))
        prob += (regular_shift_counts[i] <= max_regular_shifts)

    # **确保每个班次至少有正式工参与**
    for j in range(6):
        prob += (x_vars[j] >= 1)
        prob += (x_vars[j] == sum([regular_shifts[i][j] for i in range(regular_workers)]))

    for i in range(regular_workers):
        prob += (regular_days[i] == sum([regular_shifts[i][j - 1] for j in range(1, 7)]))

    # **确保首先使用正式员工**
    for j in range(6):
        prob += (y_vars[j] <= x_vars[j])

    # 计算平均每个班次需要的正式工人次
    average_shifts_per_worker = max_regular_shifts / regular_workers
    average_shifts_per_day_per_slot = average_shifts_per_worker / 6

    # 为每个班次添加平均分配约束
    for j in range(6):
        actual_shifts_in_slot = pulp.lpSum([regular_shifts[i][j] for i in range(regular_workers)])  # 实际在第j个班次工作的正式工人数
        # 确保实际分配人数与平均值之间的差距在可接受范围内
        prob += (actual_shifts_in_slot >= average_shifts_per_day_per_slot - M * 0.1)  # 下限约束
        prob += (actual_shifts_in_slot <= average_shifts_per_day_per_slot + M * 0.1)  # 上限约束

    # 解决问题
    prob.solve()

    return [var.varValue for var in x_vars], [var.varValue for var in y_vars]


# 判断连续出勤天数
def continue_time(stat,day):
    flag=0
    if day>7:
        for i in range(1,8):
            if stat[day-i-1]==0:
                flag=1
                break
    else:
        flag=1

    return flag
        

if __name__ == '__main__':
    # 读取预测结果数据
    df_hour = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表4.csv", encoding='GBK')
    df_hour["货量"]=df_hour["货量"].round()
    groupnamed = list(df_hour[df_hour['分拣中心'] == 'SC60'].groupby("日期").groups.keys())
    during = ["00:00-08:00", "05:00-13:00", "08:00-16:00", "12:00-20:00", "14:00-22:00", "16:00-24:00"]

    # 参数设置
    regular_workers = 200  # 正式工数量
    max_regular_shifts = int(0.85 * 30)  # 正式工最大班次数
    max_consecutive_days = 7  # 正式工连续出勤的最大天数

    # 初始化结果
    results = {"分拣中心": [], "日期": [], "班次": [], "出勤员工": []}
    employee_counter={"临时工":1}
    r_employee_counter={}   # 正式工出勤总天数
    regular_d=[[0]*30]*200  # 正式工连续出勤
    for i in range(1,201):
        r_employee_counter[f"正式工{i}"]=0

    if __name__ == '__main__':
        # 多线程处理
        with Pool() as pool:
            mday, t=0, 0  # 记录日期和出勤的正式工
            # 遍历每个日期
            for j in groupnamed:
                # 为当前分拣中心和日期创建 DataFrame
                df_hour_ij = df_hour.query("分拣中心 == 'SC60' and 日期 == @j")
                mday+=1

                # 使用多线程处理
                results_list = pool.starmap(model_day, [(df_hour_ij, regular_workers, max_regular_shifts, max_consecutive_days)])

                # 处理结果
                for regular_shifts, temp_shifts in results_list:
                    coun = []  # 记录已分配的工作人员
                    for k in range(6):
                        # 对于正式工
                        for l in range(int(regular_shifts[k])):
                            # 找到未被安排工作的正式工
                            if continue_time(regular_d[t], mday) and r_employee_counter[f"正式工{t+1}"] < max_regular_shifts and (f"正式工{t+1}" not in coun):
                                coun.append(f"正式工{t+1}")
                                results["分拣中心"].append('SC60')
                                results["日期"].append(j)
                                results["班次"].append(during[k])
                                results["出勤员工"].append(f"正式工{t+1}")
                                regular_d[t][mday-1]=1
                                # 更新正式工的总出勤天数
                                r_employee_counter[f"正式工{t+1}"] += 1
                                t=(t+1)%200
                        
                        # 对于临时工
                        employee_counter['临时工'] = 1
                        for l in range(int(temp_shifts[k])):
                            results["分拣中心"].append('SC60')
                            results["日期"].append(j)
                            results["班次"].append(during[k])
                            results["出勤员工"].append(f"临时工{employee_counter['临时工']}")
                            employee_counter['临时工'] += 1

        # 保存结果
        pd.DataFrame(results).to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表6.csv", index=False, encoding='GBK')
