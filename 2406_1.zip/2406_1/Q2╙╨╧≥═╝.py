import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# 计算出边的总权重
def sum_outgoing_weight(G, node):
    if node not in G:
        return 0
    outgoing_weights = [G[node][v]['weight'] for v in G.successors(node)]
    return sum(outgoing_weights) if outgoing_weights else 0

# 计算入边的总权重
def sum_incoming_weight(G, node):
    if node not in G:
        return 0
    incoming_weights = [G[u][node]['weight'] for u in G.predecessors(node)]
    return sum(incoming_weights) if incoming_weights else 0

# 计算出边的平均权重
def average_outgoing_weight(G, node):
    if node not in G:
        return 0
    outgoing_weights = [G[node][v]['weight'] for v in G.successors(node)]
    return sum(outgoing_weights) / len(outgoing_weights) if outgoing_weights else 0

# 计算入边的平均权重
def average_incoming_weight(G, node):
    if node not in G:
        return 0
    incoming_weights = [G[u][node]['weight'] for u in G.predecessors(node)]
    return sum(incoming_weights) / len(incoming_weights) if incoming_weights else 0

if __name__ == '__main__':
    df_day = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表1.csv", encoding='GBK')
    df_hour = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表2.csv", encoding='GBK')
    df_route_origin = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\附件\\附件3.csv", encoding='GBK')
    df_route_future = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\附件\\附件4.csv", encoding='GBK')
    graph={"start":[],"end":[],"weight":[]}

    # 构建边列表
    edges_origin = [(row['始发分拣中心'], row['到达分拣中心'], {'weight': row['货量']}) for _, row in df_route_origin.iterrows()]
    edges = [(row['始发分拣中心'], row['到达分拣中心']) for _, row in df_route_future.iterrows()]

    # 创建有向图
    G1 = nx.DiGraph()

    # 添加边和权重
    G1.add_edges_from(edges_origin)

    # 创建有向图
    G2 = nx.DiGraph()

    # 添加边和权重
    G2.add_edges_from(edges)

    # 更新图 G1 成为 G2 的形式
    # 删除 G1 中不在 G2 中的边
    edges_to_remove = [(u, v) for u, v in G1.edges() if (u, v) not in edges]
    G1.remove_edges_from(edges_to_remove)

    # 添加 G2 中存在但在 G1 中不存在的新边
    new_edges = [edge for edge in edges if edge not in G1.edges()]
    for u, v in new_edges:
        weight = (average_outgoing_weight(G1, u) + average_incoming_weight(G1, v)) / 2
        G1.add_edge(u, v, weight=weight)

    # 更新已存在的边的权重
    for u, v in G1.edges():
        weight = (average_outgoing_weight(G1, u) + average_incoming_weight(G1, v)) / 2
        G1[u][v]['weight'] = weight

    # 删除没有边的点
    isolated_nodes = [n for n in G1.nodes() if G1.degree(n) == 0]
    G1.remove_nodes_from(isolated_nodes)

    # 输出 G1 的节点和边
    print("Nodes in G1:", G1.nodes())
    print("Edges in G1:", G1.edges(data=True))

    # 存储节点和边的信息
    for i in G1.edges(data=True):
        graph["start"].append(i[0])
        graph["end"].append(i[1])
        graph["weight"].append(i[2]["weight"])

    pd.DataFrame(graph).to_csv("graph.csv", encoding='GBK')

    # 绘制有向图
    plt.figure(figsize=(20, 20))
    pos = nx.circular_layout(G1)  # 使用圆形布局
    node_colors = ['lightblue' for _ in G1.nodes()]  # 节点颜色
    edge_colors = ['black' for _ in G1.edges()]  # 边的颜色
    edge_widths = [G1[u][v]['weight'] * 0.01 for u, v in G1.edges()]  # 根据权重调整边的宽度

    nx.draw(G1, pos, with_labels=True, node_color=node_colors, node_size=500, font_size=10,
            arrows=True, arrowstyle='-|>', arrowsize=20, edge_color=edge_colors, width=edge_widths)
    edge_labels = {(u, v): f"{G1[u][v]['weight']:.2f}" for u, v in G1.edges()}  # 保留两位有效数字
    nx.draw_networkx_edge_labels(G1, pos, edge_labels=edge_labels, font_size=6, label_pos=0.5)
    plt.title('Circular Layout of Directed Graph G1')
    plt.savefig("Q2graph.png", dpi=500)
    plt.show()

    # 计算每个分拣中心的出度和入度
    groupnamed=list(df_day.groupby("分拣中心").groups.keys())
    groupnameh=list(df_hour.groupby("分拣中心").groups.keys())

    for i in groupnamed:
        df_day.loc[df_day["分拣中心"] == i, "货量"] += sum_incoming_weight(G1,i) - sum_outgoing_weight(G1,i)

    df_day.to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表3.csv", encoding='GBK', index=False)

    for i in groupnameh:
        df_hour.loc[df_hour["分拣中心"] == i,"货量"] += sum_incoming_weight(G1,i) - sum_outgoing_weight(G1,i)

    df_hour.to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表4.csv", encoding='GBK', index=False)