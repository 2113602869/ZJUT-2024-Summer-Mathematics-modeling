import pulp
import pandas as pd
from multiprocessing import Pool


# 双目标整数规划模型
def dual_objective_integer_programming_model(df):
    max_regular = 60
    worker_energy = {'Regular': 25, 'Temp': 20}
    package_demands = df["货量"].values.tolist()

    # 班次
    flag = [
        [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1]
    ]

    # 创建问题实例
    prob = pulp.LpProblem("Package_Processing_Scheduling", pulp.LpMinimize)

    # 正式工
    x_vars = [pulp.LpVariable(f"正式工班次{i}", lowBound=0, cat='Integer') for i in range(1, 7)]
    """
    # 正式工  
    x1 = pulp.LpVariable("正式工班次1", lowBound=0, cat='Integer')  
    x2 = pulp.LpVariable("正式工班次2", lowBound=0, cat='Integer')  
    x3 = pulp.LpVariable("正式工班次3", lowBound=0, cat='Integer')  
    x4 = pulp.LpVariable("正式工班次4", lowBound=0, cat='Integer')  
    x5 = pulp.LpVariable("正式工班次5", lowBound=0, cat='Integer')  
    x6 = pulp.LpVariable("正式工班次6", lowBound=0, cat='Integer') 
    x_vars = [x1, x2, x3, x4, x5, x6]
    """
    # 临时工
    y_vars = [pulp.LpVariable(f"临时工班次{i}", lowBound=0, cat='Integer') for i in range(1, 7)]
    """
    # 临时工  
    y1 = pulp.LpVariable("临时工班次1", lowBound=0, cat='Integer')  
    y2 = pulp.LpVariable("临时工班次2", lowBound=0, cat='Integer')  
    y3 = pulp.LpVariable("临时工班次3", lowBound=0, cat='Integer')  
    y4 = pulp.LpVariable("临时工班次4", lowBound=0, cat='Integer')  
    y5 = pulp.LpVariable("临时工班次5", lowBound=0, cat='Integer')  
    y6 = pulp.LpVariable("临时工班次6", lowBound=0, cat='Integer')  
    
    # 将它们组合回列表，如果需要的话  
    y_vars = [y1, y2, y3, y4, y5, y6] 
    """
    # 正式工总数
    total_regular_workers = pulp.LpVariable("TotalRegularWorkers", lowBound=0, cat='Integer')

    # 最小化临时工的使用
    prob += pulp.lpSum([0.01 * x for x in x_vars])+pulp.lpSum(y_vars)

    # 约束条件
    for i in range(24):
        prob += (
            (worker_energy["Regular"] * sum(x * f[i] for x, f in zip(x_vars, flag)) +
             worker_energy["Temp"] * sum(y * f[i] for y, f in zip(y_vars, flag))) >=
            package_demands[i]
        )
    
    """
    for i in range(24):  
    prob += (  
        (worker_energy["Regular"] * (x1 * flag[0][i] + x2 * flag[1][i] + x3 * flag[2][i] + x4 * flag[3][i] + x5 * flag[4][i] + x6 * flag[5][i]) +  
         worker_energy["Temp"] * (y1 * flag[0][i] + y2 * flag[1][i] + y3 * flag[2][i] + y4 * flag[3][i] + y5 * flag[4][i] + y6 * flag[5][i])) >=  
        package_demands[i]  
    )
    """

    # 限制正式工的使用数量
    prob += total_regular_workers == pulp.lpSum(x_vars)
    prob += total_regular_workers <= max_regular

    # 对每个临时工的使用引入额外约束
    M = 1e6  # 选择一个合适的足够大的M值
    for i in range(1, 7):
        # 当正式工总数未达上限时，允许使用临时工
        prob += y_vars[i-1] <= max_regular - total_regular_workers + M

    solver = pulp.PULP_CBC_CMD(msg=True, timeLimit=300)  # 限制求解时间为300秒
    prob.solve(solver=solver)

    # 返回结果
    return [var.varValue for var in x_vars + y_vars]


# 读取随机生成的数据
df_hour = pd.read_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表4.csv", encoding='GBK')
df_hour["货量"]=df_hour["货量"].round()

# 分组
groupnameh = list(df_hour.groupby("分拣中心").groups.keys())
during = ["00:00-08:00", "05:00-13:00", "08:00-16:00", "12:00-20:00", "14:00-22:00", "16:00-24:00"]

# 初始化结果字典
results = {"分拣中心": [], "日期": [], "班次": [], "正式工人数": [], "临时工人数": []}

if __name__ == '__main__':
    # 多线程处理
    with Pool() as pool:
        for i in groupnameh:
            groupnamed = list(df_hour.groupby("日期").groups.keys())
            for j in groupnamed:
                df_hour_ij = df_hour.query("分拣中心 == @i and 日期 == @j")
                print(df_hour_ij)
                # 使用多线程处理
                results_list = pool.map(dual_objective_integer_programming_model, [df_hour_ij] * 6)
                for k in range(6):
                    results["分拣中心"].append(i)
                    results["日期"].append(j)
                    results["班次"].append(during[k])
                    results["正式工人数"].append(results_list[k][k])
                    results["临时工人数"].append(results_list[k][k + 6])

    # 保存结果
    pd.DataFrame(results).to_csv("F:\\Python数模\\暑期培训\\2406\\结果\\结果表5.csv", index=False, encoding='GBK')
