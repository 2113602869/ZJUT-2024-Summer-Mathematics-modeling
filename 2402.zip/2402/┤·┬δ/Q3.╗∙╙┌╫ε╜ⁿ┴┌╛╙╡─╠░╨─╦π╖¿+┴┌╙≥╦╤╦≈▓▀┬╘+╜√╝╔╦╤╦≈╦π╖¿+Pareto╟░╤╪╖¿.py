import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import inequality
from geopy.distance import geodesic
import copy

"""
    ######################
    Part One:计算时间平衡函数，检验均衡性
    ######################
"""


# ----------计算洛伦兹曲线函数----------
def calculate_lorenz_curve(work_times):
    #param work_times: 一个包含28天每天工作时间的列表
    #return: 两个列表，分别表示累计天数占比和累计工作时间占比
    # 将工作时间转换为numpy数组，并进行排序
    sorted_work_times = np.sort(np.array(work_times))
    # 计算总工作时间
    total_work_time = np.sum(sorted_work_times)
    # 计算每天工作时间的占比
    work_time_proportion = sorted_work_times / total_work_time
    # 计算累计天数占比（即索引占比）
    cumulative_days_proportion = np.arange(1, len(sorted_work_times) + 1) / len(sorted_work_times)
    # 计算累计工作时间占比
    cumulative_work_time_proportion = np.cumsum(work_time_proportion)
    return cumulative_days_proportion, cumulative_work_time_proportion


# ----------绘制洛伦兹曲线函数----------
def plot_lorenz_curve(cumulative_days_proportion, cumulative_work_time_proportion):
    #cumulative_days_proportion: 累计天数占比的列表
    #cumulative_work_time_proportion: 累计工作时间占比的列表
    # 绘制洛伦兹曲线
    plt.plot(cumulative_days_proportion, cumulative_work_time_proportion, label='Lorenz Curve')
    # 绘制完全平等线（对角线）
    plt.plot([0, 1], [0, 1], 'r--', label='Line of Equality')
    # 设置图表标题和标签
    plt.title('Lorenz Curve for Daily Work Time Distribution over 28 Days')
    plt.xlabel('Cumulative Days Proportion')
    plt.ylabel('Cumulative Work Time Proportion')
    # 显示图例
    plt.legend()
    # 显示图表
    plt.show()


def Standard_deviation_test(data):
    # 计算平均值
    mean_value = np.mean(data)
    # 计算样本的标准差
    std_dev = np.std(data, ddof=1)  # ddof=1 表示自由度的更正
    # 计算样本数据的总体标准差
    population_std_dev = np.std(data, ddof=0)  # ddof=0 表示使用总体标准差的公式
    print("总体标准差是：",population_std_dev)
    threshold = 2.16  # 对应95%置信区间
    # 检验标准差是否超出阈值
    is_outlier = np.abs(data - np.mean(data)) > threshold * population_std_dev
    print("检验标准差是否有超出阈值:\n",is_outlier)
    # 数据均匀性检验
    balance_threshold = 0.08
    is_balanced = (population_std_dev / mean_value) < balance_threshold
    print(f"在阈值为{balance_threshold}的条件下，数据均匀性检验结果: {'均匀' if is_balanced else '不均匀'}")



"""
    ######################
    Part Two:处理取消每天8个点位数的限制时的工作均衡化方案的函数
    ######################
"""
# ----------定义Solution类，代表解决方案的各项指标----------
class Solution:
    def __init__(self, routes, time_matrix):
        # 该类用于直接计算总成本和平衡值
        self.routes = routes
        self.cost = sum(calculate_route_time(route, time_matrix) for route in routes)
        self.balance = calculate_time_balance(routes, time_matrix)

# ----------基于最近邻居的贪心算法构建初始解----------
def greedy_initial_solution(time_matrix):
    una_tasks = list(range(n_tasks))
    routes = []
    while una_tasks:
        current_route = []
        current_task = una_tasks.pop(0)
        current_route.append(current_task)
        while una_tasks:
            closest_task = None
            min_distance = float('inf')
            for task in una_tasks:
                if time_matrix[current_task][task] < min_distance:
                    closest_task = task
                    min_distance = time_matrix[current_task][task]
            if can_add_to_route(current_route, closest_task, time_matrix):
                current_route.append(closest_task)
                una_tasks.remove(closest_task)
                current_task = closest_task
            else:
                break
        routes.append(current_route)

    return routes


# ----------邻域搜索策略优化----------
def local_search(routes, time_matrix):
    best_routes = copy.deepcopy(routes)
    best_obj = calculate_objective(best_routes, time_matrix)

    # ----------考虑一次进行多次交换----------
    for i in range(len(routes)):
        for j in range(i + 1, len(routes)):
            for k in range(j + 1, len(routes)):
                # ---------- 一次执行两次交换----------
                try:
                    new_routes = swap_tasks(routes, i, 0, j, 0)
                    new_routes = swap_tasks(new_routes, j, 0, k, 0)
                    if is_valid_solution(new_routes, time_matrix):
                        objective = calculate_objective(new_routes, time_matrix)
                        if objective < best_obj:
                            best_routes = copy.deepcopy(new_routes)
                            best_obj = objective
                except IndexError:
                    continue

    return best_routes


# ----------禁忌搜索算法搜索最优解----------
def tabu_search(routes, time_matrix, tabu_list_size=10, max_iterations=1000):
    current_routes = copy.deepcopy(routes)
    current_obj = calculate_objective(current_routes, time_matrix)
    best_routes = copy.deepcopy(current_routes)
    best_obj = current_obj
    tabu_list = []
    iteration = 0
    while iteration < max_iterations:
        neighbor_routes = []
        for i in range(len(current_routes) - 1):
            for j in range(i + 1, len(current_routes)):
                if not current_routes[i] or not current_routes[j]:
                    continue
                for task_i in range(len(current_routes[i])):
                    for task_j in range(len(current_routes[j])):
                        if (i, task_i, j, task_j) not in tabu_list:
                            try:
                                new_routes = swap_tasks(current_routes, i, task_i, j, task_j)
                                if is_valid_solution(new_routes, time_matrix):
                                    neighbor_routes.append(
                                        (new_routes, calculate_objective(new_routes, time_matrix)))
                            except IndexError:
                                continue

        if not neighbor_routes:
            break

        neighbor_routes.sort(key=lambda x: x[1])

        selected_routes, selected_objective = neighbor_routes[0]
        if selected_objective < best_obj:
            best_routes = copy.deepcopy(selected_routes)
            best_obj = selected_objective

        current_routes = copy.deepcopy(selected_routes)
        current_obj = selected_objective

        tabu_list.append((i, task_i, j, task_j))
        if len(tabu_list) > tabu_list_size:
            tabu_list.pop(0)
        iteration += 1

    return best_routes


# --------------------其他辅助计算函数--------------------
# ----------计算路线总时间----------
def calculate_route_time(route, time_matrix):
    total_time = sum(time_matrix[route[i]][route[i + 1]] for i in range(len(route) - 1))
    total_time += sum(dwell_time[route[i]] for i in range(len(route)))
    return total_time


# ----------判断是否可以添加任务到当前路线----------
def can_add_to_route(route, task, time_matrix):
    new_route = route + [task]
    return calculate_route_time(new_route, time_matrix) <= max_work_time


# ----------计算总成本----------
def calculate_total_cost(routes, time_matrix):
    return sum(calculate_route_time(route, time_matrix) for route in routes)


# ----------判断是否是有效的解决方案----------
def is_valid_solution(routes, time_matrix, min_tasks_per_route=1):
    if any(len(route) < min_tasks_per_route for route in routes):
        return False
    return all(calculate_route_time(route, time_matrix) <= max_work_time for route in routes)


# ----------交换任务----------
def swap_tasks(routes, route_index1, task_index1, route_index2, task_index2):
    new_routes = copy.deepcopy(routes)

    # 确保route_index1和route_index2有效
    if route_index1 >= len(new_routes) or route_index2 >= len(new_routes):
        raise IndexError("Route index out of range.")

    # 确保task_index1和task_index2在各自路线的有效范围内
    if task_index1 >= len(new_routes[route_index1]) or task_index2 >= len(new_routes[route_index2]):
        raise IndexError("Task index out of range.")

    task1 = new_routes[route_index1].pop(task_index1)
    task2 = new_routes[route_index2].pop(task_index2)

    new_routes[route_index1].insert(task_index1, task2)
    new_routes[route_index2].insert(task_index2, task1)

    return new_routes


# ----------计算时间均衡性----------
def calculate_time_balance(routes, time_matrix):
    times = [calculate_route_time(route, time_matrix) for route in routes]
    average_time = sum(times) / len(times)
    return sum((time - average_time) ** 2 for time in times) / len(times)


# ----------Pareto最优检查----------
def is_pareto_optimal(candidate, solutions):
    for solution in solutions:
        if all(candidate[i] >= solution[i] for i in range(len(candidate))) and any(
                candidate[i] > solution[i] for i in range(len(candidate))):
            return False
    return True


# ----------更新Pareto前沿----------
def update_pareto_frontier(frontier, candidate, time_matrix):
    candidate_solution = Solution(candidate, time_matrix)
    key = (candidate_solution.cost, candidate_solution.balance)
    if key not in frontier or candidate_solution < frontier[key]:
        frontier[key] = candidate_solution


# ----------计算目标函数----------
def calculate_objective(routes, time_matrix, weight_cost=0.1, weight_balance=0.9):
    cost = calculate_total_cost(routes, time_matrix)
    balance = calculate_time_balance(routes, time_matrix)
    return weight_cost * cost + weight_balance * balance


# ----------计算路线时间----------
def balance_routes(routes, time_matrix, threshold):
    # 计算当前均衡性
    times = [calculate_route_time(route, time_matrix) for route in routes]
    average_time = sum(times) / len(times)

    # 当存在明显的不平衡
    while max(times) - min(times) > threshold:
        # 找到最长和最短的路线
        longest_route_index = times.index(max(times))
        shortest_route_index = times.index(min(times))

        # 将任务从最长路径移动到最短路径
        for i, task in enumerate(routes[longest_route_index]):
            new_routes = copy.deepcopy(routes)
            new_routes[longest_route_index].remove(task)
            new_routes[shortest_route_index].append(task)
            if is_valid_solution(new_routes, time_matrix):
                routes = new_routes
                times = [calculate_route_time(route, time_matrix) for route in routes]
                break

    return routes


"""
    ######################
    Part Three:主程序
    ######################
"""
if __name__ == '__main__':
    # ----------评判第二问的数据是否均衡----------
    # 计算Gini系数
    df2 = pd.read_excel("题2时间.xlsx")
    t2_time = df2['工作时长/min'].values.tolist()
    gini = inequality.gini._gini(t2_time)
    print("第二问数据Gini系数为：", gini)
    Standard_deviation_test(np.array(t2_time))
    
    # 绘制洛伦兹曲线
    cumulative_days_proportion, cumulative_work_time_proportion = calculate_lorenz_curve(t2_time)
    plot_lorenz_curve(cumulative_days_proportion, cumulative_work_time_proportion)


    # ----------导入数据，建立必需的变量----------
    df = pd.read_excel("附件1：xx地区.xlsx")
    points_origin = df[['JD', 'WD']].values.tolist()
    point_index = df['序号'].values.tolist()
    speed = 20
    dwell_time = df['完成工作所需时间（分钟）'].values.tolist()
    graph = []
    pareto_frontier = {}
    points = df[['JD', 'WD', '完成工作所需时间（分钟）']].values.tolist()
    max_work_time = 8.5 * 60  # 最大工作时间，单位：分钟
    n_tasks = len(points)

    #----------计算时间矩阵----------
    for i in range(len(points_origin)):
        graph.append([])
        for j in range(len(points_origin)):
            graph[i].append(geodesic((points_origin[i][1], points_origin[i][0]),
                                     (points_origin[j][1], points_origin[j][0])).kilometers / speed * 60)
    #print(graph)

    # ----------调用算法，解决问题----------
    initial_routes = greedy_initial_solution(graph)
    optimized_routes = local_search(initial_routes, graph)
    final_routes = tabu_search(optimized_routes, graph)

    # ----------输出初步结果----------
    for i, route in enumerate(final_routes):
        route_time = calculate_route_time(route, graph)
        print(f"Route {i + 1}: Tasks {route}, Total Time: {route_time} minutes")

    # ----------平衡路线----------
    final_routes = balance_routes(final_routes, graph, 10)
    final_routes_solution = Solution(final_routes, graph)
    update_pareto_frontier(pareto_frontier, final_routes, graph)

    # ----------输出Pareto前沿上的解决方案----------
    for (cost, balance), solution in pareto_frontier.items():
        routes = solution.routes
        # 使用cost, balance和routes进行进一步的处理
        print(f"Cost: {cost}, Balance: {balance}, Routes: {routes}")

    # ----------输出最终结果----------
    for i, route in enumerate(final_routes):
        route_time = calculate_route_time(route, graph)
        print(f"Route {i + 1}: Tasks {route}, Total Time: {route_time} minutes")
