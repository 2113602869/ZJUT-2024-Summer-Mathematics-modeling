import pandas as pd
import requests
import xml.etree.ElementTree as ET
import json


# ----------高德/腾讯地图API密钥----------
GDKEY = "9d80ac0cf229781f7aae1fba5b6c6a44"
TXKEY = "UARBZ-QEWWB-VBKUH-NGJEJ-NJVUQ-VQBKO"

# ----------通过高德地图API获取距离、时长----------
def gd_getDistance_and_time(start, end):
    url = f"https://restapi.amap.com/v3/direction/driving?origin={start}&destination={end}&extensions=all&output=xml&key={GDKEY}"
    res = requests.get(url)
    root = ET.fromstring(res.text)
    if root.find('.//status').text == "1":
        return (float(root.find('.//distance').text)/ 1000, round(float(root.find('.//duration').text)/60,1))
    else:
        print(root.find('.//info').text)
        return -1

# ----------通过腾讯地图API获取距离、时长----------
def tx_getDistance_and_time(start, end):
    url = f"https://apis.map.qq.com/ws/direction/v1/driving/?from={start}&to={end}&waypoints=&output=json&callback=cb&key={TXKEY}"
    res = requests.get(url)
    json_data = json.loads(res.text)
    if json_data["status"] == 0:
        return (float(json_data["result"]["routes"][0]["distance"])/1000, float(json_data["result"]["routes"][0]["duration"]))
    else:
        print(json_data["message"])
        return -1

# ----------Floyd-Warshall算法实现，返回所有点对之间的最短路径长度----------
def floyd_warshall(graph):
    num_vertices = len(graph)
    dist = [[graph[i][j] for j in range(num_vertices)] for i in range(num_vertices)]
    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                if dist[i][j] > dist[i][k] + dist[k][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
    return dist

# ----------使用回溯策略来构建一个访问所有点的路径，并找到最短时间----------
def find_path(dist, num_vertices):
    visited = [False] * num_vertices
    path = []
    min_time = float('infinity')
    def dfs(node, current_path, current_time):
        nonlocal min_time, path
        visited[node] = True
        current_path.append(node)
        if len(current_path) == num_vertices:
            if current_time < min_time:
                min_time = current_time
                path = current_path[:]
        else:
            for next_node in range(num_vertices):
                if not visited[next_node]:
                    dfs(next_node, current_path, current_time + dist[node][next_node])
        visited[node] = False
        current_path.pop()

    # 从每个节点开始尝试
    for start_node in range(num_vertices):
        dfs(start_node, [], 0)
    return min_time, path

# ----------读取数据----------
df=pd.read_excel("附件1：xx地区.xlsx")
points_index=[31,44,61,83,100,115,147,158]
points_detail=[]
dwell_time=[0]*len(points_index)
gd_distanse_graph=[]
gd_time_graph=[]
tx_distanse_graph=[]
tx_time_graph=[]

#----------提取所需点位----------
for i in range(len(points_index)):
    points_detail.append(list(df.iloc[points_index[i]-1]))
    dwell_time[i]=points_detail[i][3]

#----------计算时间矩阵----------
for i in range(len(points_detail)):
    gd_start=str(points_detail[i][1])+","+str(points_detail[i][2])  #gd
    tx_start = str(points_detail[i][2]) + "," + str(points_detail[i][1])  #tx
    gd_distanse_graph.append([])
    gd_time_graph.append([])
    tx_distanse_graph.append([])
    tx_time_graph.append([])
    for j in range(len(points_detail)):
        gd_end=str(points_detail[j][1])+","+str(points_detail[j][2]) #gd
        tx_end = str(points_detail[j][2]) + "," + str(points_detail[j][1])  #tx
        if i==j:
            gd_distanse_graph[i].append(0)
            gd_time_graph[i].append(0)
            tx_distanse_graph[i].append(0)
            tx_time_graph[i].append(0)
        else:
            gd_results=gd_getDistance_and_time(gd_start,gd_end)
            tx_results=tx_getDistance_and_time(tx_start,tx_end)
            gd_distanse_graph[i].append(gd_results[0])
            gd_time_graph[i].append(gd_results[1])
            tx_distanse_graph[i].append(tx_results[0])
            tx_time_graph[i].append(tx_results[1])
#----------输出行车结果----------
print(gd_distanse_graph)
print(gd_time_graph)
print(tx_distanse_graph)
print(tx_time_graph)

gd_num_vertices = len(gd_time_graph)
tx_num_vertices = len(tx_time_graph)

# ----------计算所有点对之间的最短路径----------
gd_dist = floyd_warshall(gd_time_graph)
tx_dist = floyd_warshall(tx_time_graph)

# ----------找到一个访问所有点的最短单向路径及其时间----------
gd_min_time, gd_path = find_path(gd_dist, gd_num_vertices)
tx_min_time, tx_path = find_path(tx_dist, tx_num_vertices)
#print(gd_min_time,tx_min_time)
# ----------比较两种地图的导航结果，输出最终结果----------
if (gd_min_time<tx_min_time):
    print("----------------------------------------------------------------------------------")
    print("Enable Amap Navigation!!!") #高德
    print("The shortest time:", gd_min_time+sum(dwell_time))
    print("The optimal path is",end=":")
    for i in range(len(gd_path)-1):
        print(points_index[gd_path[i]],end=" -> ")
    print(points_index[gd_path[-1]])
else:
    print("----------------------------------------------------------------------------------")
    print("Enable Tencent Maps Navigation!!!")#腾讯
    print("The shortest time:", tx_min_time+sum(dwell_time))
    print("The optimal path is",end=":")
    for i in range(len(tx_path)-1):
        print(points_index[tx_path[i]],end=" -> ")
    print(points_index[tx_path[-1]])
