% 假设 adjacency_matrix 是一个 n × n 的邻接矩阵，表示完全图的权重
function adjacency_matrix = calculate_adjacency_matrix(coordinates)
    n = size(coordinates, 1);
    adjacency_matrix = zeros(n);

    % 计算节点之间的球面距离，并作为权重填充邻接矩阵
    for i = 1:n
        for j = 1:n
            if i ~= j
                lat1 = deg2rad(coordinates(i, 1));
                lon1 = deg2rad(coordinates(i, 2));
                lat2 = deg2rad(coordinates(j, 1));
                lon2 = deg2rad(coordinates(j, 2));

                % 使用 Haversine 公式计算球面距离
                R = 6371; % 地球半径（单位：公里）
                dlat = lat2 - lat1;
                dlon = lon2 - lon1;
                a = sin(dlat/2)^2 + cos(lat1) * cos(lat2) * sin(dlon/2)^2;
                c = 2 * atan2(sqrt(a), sqrt(1-a));
                distance = R * c;

                % 填充邻接矩阵
                adjacency_matrix(i, j) = distance;
            end
        end
    end
end

% 给出每个节点的经纬度坐标