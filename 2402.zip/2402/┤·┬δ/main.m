
coordinates = [
    38.110755,111.040331; %6
    38.112507,111.042637; 
    38.117061,111.073839;
    38.116762,111.069797;
    38.124064,111.057493;
    38.119702,111.044954;
    38.118705,111.046929; 
    38.127754,111.065254;
  
];%将每一个点作为索引顺序为1的点依次尝试，得到当第六个点的索引为1时距离最短。

adjacency_matrix = calculate_adjacency_matrix(coordinates);

shortest_hamiltonian_path = find_shortest_hamiltonian_path(adjacency_matrix);
disp('最短的哈密顿路径：');
disp(shortest_hamiltonian_path);
total_distance = calculate_path_distance(shortest_hamiltonian_path, adjacency_matrix);  
disp('最短的哈密尔顿路径的总距离：');  
disp(total_distance);