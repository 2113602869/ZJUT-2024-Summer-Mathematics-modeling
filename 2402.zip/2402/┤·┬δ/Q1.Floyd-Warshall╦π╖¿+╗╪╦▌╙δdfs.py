import pandas as pd
from geopy.distance import geodesic

# Floyd-Warshall算法实现，返回所有点对之间的最短路径长度
def floyd_warshall(graph):

    num_vertices = len(graph)
    dist = [[graph[i][j] for j in range(num_vertices)] for i in range(num_vertices)]

    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                if dist[i][j] > dist[i][k] + dist[k][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
    return dist

# 使用回溯策略来构建一个访问所有点的路径，并找到最短时间
def find_path(dist, num_vertices):

    visited = [False] * num_vertices
    path = []
    min_time = float('infinity')

    def dfs(node, current_path, current_time):
        nonlocal min_time, path
        visited[node] = True
        current_path.append(node)

        if len(current_path) == num_vertices:
            if current_time < min_time:
                min_time = current_time
                path = current_path[:]
        else:
            for next_node in range(num_vertices):
                if not visited[next_node]:
                    dfs(next_node, current_path, current_time + dist[node][next_node])

        visited[node] = False
        current_path.pop()

    # 从每个节点开始尝试
    for start_node in range(num_vertices):
        dfs(start_node, [], 0)

    return min_time, path

"""
# 示例数据和调用
graph = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]"""
#----------读取数据----------
df=pd.read_excel("附件1：xx地区.xlsx")
points_index=[31,44,61,83,100,115,147,158]
points_detail=[]
speed=20
dwell_time=[0,0,0,0,0,0,0,0]
graph=[]

#----------提取所需点位----------
for i in range(len(points_index)):
    points_detail.append(list(df.iloc[points_index[i]-1]))
    dwell_time[i]=points_detail[i][3]
#print(dwell_time)
#print(points_detail)

#----------计算时间矩阵----------
for i in range(len(points_detail)):
    graph.append([])
    for j in range(len(points_detail)):
        graph[i].append(geodesic((points_detail[i][2], points_detail[i][1]), (points_detail[j][2], points_detail[j][1])).kilometers/speed*60)
#print(travel_time_matrix)
num_vertices = len(graph)

# 计算所有点对之间的最短路径
dist = floyd_warshall(graph)

# 找到一个访问所有点的最短单向路径及其时间
min_time, path = find_path(dist, num_vertices)

#----------输出结果----------
print("----------------------------------------------------------------------------------")
print("最短时间:", min_time+sum(dwell_time))
print("最优路径为",end=":")
for i in range(len(path)-1):
    print(points_index[path[i]],end=" -> ")
print(points_index[path[-1]])