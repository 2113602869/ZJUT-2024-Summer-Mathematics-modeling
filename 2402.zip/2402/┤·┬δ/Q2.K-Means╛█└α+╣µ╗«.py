import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from pyproj import Proj, transform
from geopy.distance import geodesic


# ----------Floyd-Warshall算法实现，返回所有点对之间的最短路径长度----------
def floyd_warshall(graph):
    num_vertices = len(graph)
    dist = [[graph[i][j] for j in range(num_vertices)] for i in range(num_vertices)]
    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                if dist[i][j] > dist[i][k] + dist[k][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
    return dist


# ----------使用回溯策略深度搜索dfs来构建一个访问所有点的路径并找到最短时间----------
def find_path(dist, num_vertice):
    visit = [False] * num_vertice
    path = []
    min_time = float('infinity')
    def dfs(nodes, cr_path, cr_time):
        nonlocal min_time, path
        visit[nodes] = True
        cr_path.append(nodes)
        if len(cr_path) == num_vertice:
            if cr_time < min_time:
                min_time = cr_time
                path = cr_path[:]
        else:
            for nextNode in range(num_vertice):
                if not visit[nextNode]:
                    dfs(nextNode, cr_path, cr_time + dist[nodes][nextNode])
        visit[nodes] = False
        cr_path.pop()

    # ----------从每个节点开始尝试----------
    for startNode in range(num_vertice):
        dfs(startNode, [], 0)
    return min_time, path


# ----------使用贪心算法调整分组----------
def adjust_cluster(clusters):
    # ----------确定哪些组需要调整----------
    cluster_s = np.array([len(cluster) for cluster in clusters])
    targer_s = 8
    last_cs = 6

    # ----------使用贪心算法进行调整----------
    while not all(cluster_s == targer_s) and not (
            np.all(cluster_s[:-1] == targer_s) and cluster_s[-1] == last_cs):
        # ----------找到需要移除点的组和需要添加点的组----------
        too_big = np.where(cluster_s > targer_s)[0]
        too_small = np.where(cluster_s < targer_s)[0]

        if too_big.size > 0 and too_small.size > 0:
            # ----------选择一个太大的组和一个太小的组----------
            from_idx = too_big[0]
            to_idx = too_small[0]

            # ----------检查选定的太大组是否不为空----------
            if len(clusters[from_idx]) > 0:
                # ----------从太大的组中移除一个点，并添加到太小的组中----------
                point_to_move = clusters[from_idx].pop()
                clusters[to_idx].append(point_to_move)

                # ----------更新组大小----------
                cluster_s[from_idx] -= 1
                cluster_s[to_idx] += 1
            else:
                # ----------如果选定的太大组为空，则跳出循环并打印错误消息----------
                print("Error: Attempted to pop from an empty cluster.")
                break
        else:
            # ----------如果没有太大或太小的组可以调整，就打破循环----------
            break

    return clusters

# ----------定义WGS 84坐标系----------
wgs84 = Proj(proj='latlong', datum='WGS84')

# ----------定义UTM坐标系（以区域33N为例）----------
utm = Proj(proj='utm', zone=33, datum='WGS84')

# ----------读取数据----------
df = pd.read_excel("附件1：xx地区.xlsx")
point_original = df[['JD', 'WD']].values.tolist()

# ----------将WGS 84坐标转换为UTM坐标----------
x, y = transform(wgs84, utm, df['JD'].values, df['WD'].values)
points=list(zip(x,y))

# ----------使用K-means聚类----------
num_clusters = int(np.ceil(len(points) / 8))  # 计算需要的聚类数量
kmeans = KMeans(n_clusters=num_clusters, random_state=1).fit(points)
labels = kmeans.labels_

# ----------聚类结果转换为分组----------
clusters = [[] for _ in range(num_clusters)]
for i, label in enumerate(labels):
    clusters[label].append(points[i])

# ----------调整后的分组----------
adjusted_clusters = adjust_cluster(clusters)

# ----------打印聚类结果----------
#for i, cluster in enumerate(adjusted_clusters):
#    print(f"Group {i + 1}: {cluster}")

results= {}
# ----------汇总聚类结果----------
for i, cluster in enumerate(adjusted_clusters):
    groups=[]
    for j in range(len(cluster)):
        groups.append(points.index(cluster[j])+1)
    results[f"第{i+1}天"]=groups

#file_name=0
for i in adjusted_clusters:
    # ----------提取x和y坐标----------
    x = [co[0] for co in i]
    y = [co[1] for co in i]

    # ----------绘制散点图----------
    plt.scatter(x, y)
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')
    plt.title('Total Scatter Plot of Coordinates')
    #plt.title(f'{i}Scatter Plot of Coordinates')

    # ----------保存每个簇的散点图----------
    #plt.savefig(f"2.{file_name+1}.png")
    #file_name += 1
    #plt.show()

# ----------保存总图----------
plt.savefig("2.total.png")
plt.show()

timedata=[]
for key, value in results.items():
    print("----------------------------------------------------------------------------------")
    print(f"{key}: {value}")
    points_detail = []
    speed = 20
    dwell_time = [0] * len(value)
    graph = []
    for i in range(len(value)):
        points_detail.append(list(df.iloc[value[i] - 1]))
        dwell_time[i] = points_detail[i][3]
    for i in range(len(points_detail)):
        graph.append([])
        for j in range(len(points_detail)):
            graph[i].append(geodesic((points_detail[i][2], points_detail[i][1]),
                                     (points_detail[j][2], points_detail[j][1])).kilometers / speed * 60)
    # print(travel_time_matrix)
    num_vertices = len(graph)
    dist = floyd_warshall(graph)
    min_time, path = find_path(dist, num_vertices)
    timedata.append([key,min_time + sum(dwell_time)])
    print(f"{key}最短时间:{min_time + sum(dwell_time)} min")
    print(f"{key}最优路径为", end=":")
    for i in range(len(path) - 1):
        print(value[path[i]], end=" -> ")
    print(value[path[-1]])
    print("----------------------------------------------------------------------------------")

# ----------保存时间结果----------
df2=pd.DataFrame(timedata,columns=["日期","工作时长/min"])
df2.to_excel("题2时间.xlsx",index=False)

# ----------对时间结果进行冒泡排序----------
for i in range(len(timedata)):
    for j in range(len(timedata)-1,i,-1):
        if timedata[j][1]<timedata[j-1][1]:
            timedata[j],timedata[j-1]=timedata[j-1],timedata[j]

# ----------输出最终结果----------
print("----------------------------------------------------------------------------------")
print("综上所述:")
print("1、排序结果:",timedata)
print(f"2、整个周期内工作时间最短的是{timedata[0][0]}，当天最优时间为{timedata[0][1]} min")
print(f"3、前27天内工作时间最短的是{timedata[1][0]}，当天最优时间为{timedata[1][1]} min")
print(f"4、整个周期内工作时间最长的是{timedata[-1][0]}，当天最优时间为{timedata[-1][1]} min")
print("----------------------------------------------------------------------------------")