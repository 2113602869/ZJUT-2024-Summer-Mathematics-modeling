function shortest_hamiltonian_path = find_shortest_hamiltonian_path(adjacency_matrix)  
    n = size(adjacency_matrix, 1);  
    shortest_path = [];  
    shortest_length = Inf;  
  
    path = [1];  
    visited = zeros(1, n);  
    visited(1) = 1;  
  
    function backtrack(current_node, current_length, path)  
        if length(path) == n  
            % 当路径长度为 n 时，我们找到了一条哈密顿路径  
            if current_length < shortest_length  
                shortest_length = current_length;  
                shortest_path = path;  
            end  
            return;  
        end  
  
        for next_node = 1:n  
            if ~visited(next_node)  
                visited(next_node) = 1;  
                backtrack(next_node, current_length + adjacency_matrix(current_node, next_node), [path, next_node]);  
                visited(next_node) = 0;  
            end  
        end  
    end  
  
    backtrack(1, 0, path);  
    shortest_hamiltonian_path = shortest_path;  
end  
