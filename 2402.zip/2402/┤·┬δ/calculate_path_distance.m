function total_distance = calculate_path_distance(path, adjacency_matrix)  
    n = length(path);  
    total_distance = 0;  
    for i = 1:n-1  % 遍历路径中的边（不包括回到起点的边）  
        total_distance = total_distance + adjacency_matrix(path(i), path(i+1));  
    end  
end  
%将最小距离依次相加得到结果